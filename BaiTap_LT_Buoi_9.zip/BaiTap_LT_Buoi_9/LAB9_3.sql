-- PHIEU BAI TAP 3

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE Dangky CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN NULL;
END;
/
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE Lophoc CASCADE CONSTRAINTS';
EXCEPTION
    WHEN OTHERS THEN NULL;
END;
/

CREATE TABLE Lophoc (
    Malop VARCHAR2(10) PRIMARY KEY,
    Tenlop VARCHAR2(100),
    Sisotoida NUMBER,
    Sisohientai NUMBER
);

CREATE TABLE Dangky (
    Madk NUMBER PRIMARY KEY,
    Masv VARCHAR2(20),
    Malop VARCHAR2(10),
    Ngaydangky DATE,
    FOREIGN KEY (Malop) REFERENCES Lophoc(Malop)
);

INSERT INTO Lophoc VALUES ('L01', 'Co so du lieu', 3, 0);
INSERT INTO Lophoc VALUES ('L02', 'Lap trinh Java', 2, 0);
INSERT INTO Lophoc VALUES ('L03', 'He quan tri CSDL', 2, 0);
COMMIT;

-- BAI 1 - Trigger INSERT tren bang DANGKY
CREATE OR REPLACE TRIGGER trg_dangky_insert
BEFORE INSERT ON Dangky
FOR EACH ROW
DECLARE
    v_sisohientai NUMBER;
    v_sisotoida NUMBER;
    v_count NUMBER;
BEGIN
    SELECT Sisohientai, Sisotoida
    INTO v_sisohientai, v_sisotoida
    FROM Lophoc
    WHERE Malop = :NEW.Malop;

    SELECT COUNT(*)
    INTO v_count
    FROM Dangky
    WHERE Masv = :NEW.Masv
      AND Malop = :NEW.Malop;

    IF v_count > 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Sinh vien da dang ky lop nay');
    END IF;

    IF v_sisohientai >= v_sisotoida THEN
        RAISE_APPLICATION_ERROR(-20002, 'Lop da day');
    END IF;

    UPDATE Lophoc
    SET Sisohientai = Sisohientai + 1
    WHERE Malop = :NEW.Malop;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20003, 'Ma lop khong ton tai');
END;
/

-- Goi trigger (test):
INSERT INTO Dangky VALUES (1, 'SV01', 'L01', SYSDATE);
INSERT INTO Dangky VALUES (2, 'SV02', 'L01', SYSDATE);

SELECT * FROM Lophoc;
SELECT * FROM Dangky;

-- Test loi:
-- INSERT INTO Dangky VALUES (3, 'SV01', 'L01', SYSDATE);
-- INSERT INTO Dangky VALUES (4, 'SV03', 'L99', SYSDATE);
-- INSERT INTO Dangky VALUES (5, 'SV03', 'L01', SYSDATE);
-- INSERT INTO Dangky VALUES (6, 'SV04', 'L01', SYSDATE);

-- BAI 2 - Trigger DELETE tren bang DANGKY
CREATE OR REPLACE TRIGGER trg_dangky_delete
AFTER DELETE ON Dangky
FOR EACH ROW
BEGIN
    UPDATE Lophoc
    SET Sisohientai = Sisohientai - 1
    WHERE Malop = :OLD.Malop;
END;
/

-- Goi trigger (test):
DELETE FROM Dangky
WHERE Madk = 2;

SELECT * FROM Lophoc;
SELECT * FROM Dangky;

-- BAI 3 - Trigger UPDATE tren bang DANGKY
CREATE OR REPLACE TRIGGER trg_dangky_update
BEFORE UPDATE OF Malop ON Dangky
FOR EACH ROW
DECLARE
    v_sisohientai NUMBER;
    v_sisotoida NUMBER;
    v_count NUMBER;
BEGIN
    SELECT Sisohientai, Sisotoida
    INTO v_sisohientai, v_sisotoida
    FROM Lophoc
    WHERE Malop = :NEW.Malop;

    SELECT COUNT(*)
    INTO v_count
    FROM Dangky
    WHERE Masv = :OLD.Masv
      AND Malop = :NEW.Malop;

    IF v_count > 0 THEN
        RAISE_APPLICATION_ERROR(-20011, 'Sinh vien da ton tai trong lop moi');
    END IF;

    IF v_sisohientai >= v_sisotoida THEN
        RAISE_APPLICATION_ERROR(-20012, 'Lop moi da day');
    END IF;

    UPDATE Lophoc
    SET Sisohientai = Sisohientai - 1
    WHERE Malop = :OLD.Malop;

    UPDATE Lophoc
    SET Sisohientai = Sisohientai + 1
    WHERE Malop = :NEW.Malop;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20013, 'Ma lop moi khong ton tai');
END;
/

-- Goi trigger (test):
INSERT INTO Dangky VALUES (3, 'SV03', 'L02', SYSDATE);

UPDATE Dangky
SET Malop = 'L02'
WHERE Madk = 1;

SELECT * FROM Lophoc;
SELECT * FROM Dangky;

-- Test loi:
-- UPDATE Dangky SET Malop = 'L99' WHERE Madk = 3;
-- UPDATE Dangky SET Malop = 'L02' WHERE Madk = 3;