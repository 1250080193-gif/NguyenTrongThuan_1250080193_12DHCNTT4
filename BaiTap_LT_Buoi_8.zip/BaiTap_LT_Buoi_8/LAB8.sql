SET SERVEROUTPUT ON;

-- XOA DU LIEU CU NEU DA TON TAI

BEGIN EXECUTE IMMEDIATE 'DROP TABLE Xuat CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE PXuat CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE Nhap CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE PNhap CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE SanPham CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE NhanVien CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE HangSX CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_NhapHangSX'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_NhapSP'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_XoaHangSX'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_NhapNhanVien'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_Nhap'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_Xuat'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_XoaNhanVien'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_XoaSanPham'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_ThemNhanVien'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_ThemMoiSP'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_XoaNhanVien_OUT'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_XoaSanPham_OUT'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_NhapHangSX_OUT'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_Nhap_OUT'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_Xuat_OUT'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- TAO BANG

CREATE TABLE HangSX (
    MaHangSX VARCHAR2(10) CONSTRAINT pk_hangsx PRIMARY KEY,
    TenHang  VARCHAR2(30) NOT NULL,
    DiaChi   VARCHAR2(50),
    SoDT     VARCHAR2(15),
    Email    VARCHAR2(50)
);

CREATE TABLE SanPham (
    MaSP       VARCHAR2(10) CONSTRAINT pk_sanpham PRIMARY KEY,
    MaHangSX   VARCHAR2(10),
    TenSP      VARCHAR2(50) NOT NULL,
    SoLuong    NUMBER(10),
    MauSac     VARCHAR2(20),
    GiaBan     NUMBER(15,2),
    DonViTinh  VARCHAR2(15),
    MoTa       CLOB,
    CONSTRAINT fk_sanpham_hangsx FOREIGN KEY (MaHangSX)
        REFERENCES HangSX(MaHangSX)
);

CREATE TABLE NhanVien (
    MaNV      VARCHAR2(10) CONSTRAINT pk_nhanvien PRIMARY KEY,
    TenNV     VARCHAR2(50) NOT NULL,
    GioiTinh  VARCHAR2(10),
    DiaChi    VARCHAR2(100),
    SoDT      VARCHAR2(15),
    Email     VARCHAR2(50),
    TenPhong  VARCHAR2(30)
);

CREATE TABLE PNhap (
    SoHDN     VARCHAR2(10) CONSTRAINT pk_pnhap PRIMARY KEY,
    NgayNhap  DATE,
    MaNV      VARCHAR2(10),
    CONSTRAINT fk_pnhap_nhanvien FOREIGN KEY (MaNV)
        REFERENCES NhanVien(MaNV)
);

CREATE TABLE Nhap (
    SoHDN      VARCHAR2(10),
    MaSP       VARCHAR2(10),
    SoLuongN   NUMBER(10),
    DonGiaN    NUMBER(15,2),
    CONSTRAINT pk_nhap PRIMARY KEY (SoHDN, MaSP),
    CONSTRAINT fk_nhap_pnhap FOREIGN KEY (SoHDN)
        REFERENCES PNhap(SoHDN),
    CONSTRAINT fk_nhap_sanpham FOREIGN KEY (MaSP)
        REFERENCES SanPham(MaSP)
);

CREATE TABLE PXuat (
    SoHDX     VARCHAR2(10) CONSTRAINT pk_pxuat PRIMARY KEY,
    NgayXuat  DATE,
    MaNV      VARCHAR2(10),
    CONSTRAINT fk_pxuat_nhanvien FOREIGN KEY (MaNV)
        REFERENCES NhanVien(MaNV)
);

CREATE TABLE Xuat (
    SoHDX      VARCHAR2(10),
    MaSP       VARCHAR2(10),
    SoLuongX   NUMBER(10),
    CONSTRAINT pk_xuat PRIMARY KEY (SoHDX, MaSP),
    CONSTRAINT fk_xuat_pxuat FOREIGN KEY (SoHDX)
        REFERENCES PXuat(SoHDX),
    CONSTRAINT fk_xuat_sanpham FOREIGN KEY (MaSP)
        REFERENCES SanPham(MaSP)
);
-- PHIEU BAI TAP 1

-- a. Thủ tục sp_NhapHangSX
CREATE OR REPLACE PROCEDURE sp_NhapHangSX
(
    p_MaHangSX IN VARCHAR2,
    p_TenHang  IN VARCHAR2,
    p_DiaChi   IN VARCHAR2,
    p_SoDT     IN VARCHAR2,
    p_Email    IN VARCHAR2
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM HangSX
    WHERE TenHang = p_TenHang;

    IF v_count > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang da ton tai');
    ELSE
        INSERT INTO HangSX(MaHangSX, TenHang, DiaChi, SoDT, Email)
        VALUES(p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);

        DBMS_OUTPUT.PUT_LINE('Them hang san xuat thanh cong');
    END IF;
END;
/
SHOW ERRORS;

-- b. Thủ tục sp_NhapSP
CREATE OR REPLACE PROCEDURE sp_NhapSP
(
    p_MaSP       IN VARCHAR2,
    p_TenHang    IN VARCHAR2,
    p_TenSP      IN VARCHAR2,
    p_SoLuong    IN NUMBER,
    p_MauSac     IN VARCHAR2,
    p_GiaBan     IN NUMBER,
    p_DonViTinh  IN VARCHAR2,
    p_MoTa       IN CLOB
)
AS
    v_MaHangSX VARCHAR2(10);
    v_count    NUMBER;
BEGIN
    SELECT MaHangSX INTO v_MaHangSX
    FROM HangSX
    WHERE TenHang = p_TenHang;

    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_count > 0 THEN
        UPDATE SanPham
        SET MaHangSX  = v_MaHangSX,
            TenSP     = p_TenSP,
            SoLuong   = p_SoLuong,
            MauSac    = p_MauSac,
            GiaBan    = p_GiaBan,
            DonViTinh = p_DonViTinh,
            MoTa      = p_MoTa
        WHERE MaSP = p_MaSP;

        DBMS_OUTPUT.PUT_LINE('Cap nhat san pham thanh cong');
    ELSE
        INSERT INTO SanPham(MaSP, MaHangSX, TenSP, SoLuong, MauSac, GiaBan, DonViTinh, MoTa)
        VALUES(p_MaSP, v_MaHangSX, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);

        DBMS_OUTPUT.PUT_LINE('Them san pham thanh cong');
    END IF;

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang khong ton tai');
END;
/
SHOW ERRORS;

-- c. Thủ tục sp_XoaHangSX
CREATE OR REPLACE PROCEDURE sp_XoaHangSX
(
    p_TenHang IN VARCHAR2
)
AS
    v_MaHangSX VARCHAR2(10);
BEGIN
    SELECT MaHangSX INTO v_MaHangSX
    FROM HangSX
    WHERE TenHang = p_TenHang;

    DELETE FROM Nhap
    WHERE MaSP IN (
        SELECT MaSP
        FROM SanPham
        WHERE MaHangSX = v_MaHangSX
    );

    DELETE FROM Xuat
    WHERE MaSP IN (
        SELECT MaSP
        FROM SanPham
        WHERE MaHangSX = v_MaHangSX
    );

    DELETE FROM SanPham
    WHERE MaHangSX = v_MaHangSX;

    DELETE FROM HangSX
    WHERE MaHangSX = v_MaHangSX;

    DBMS_OUTPUT.PUT_LINE('Xoa hang san xuat thanh cong');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Ten hang khong ton tai');
END;
/
SHOW ERRORS;

-- d. Thủ tục nhập dữ liệu NhanVien (có biến FLAG)
CREATE OR REPLACE PROCEDURE sp_NhapNhanVien
(
    p_MaNV      IN VARCHAR2,
    p_TenNV     IN VARCHAR2,
    p_GioiTinh  IN VARCHAR2,
    p_DiaChi    IN VARCHAR2,
    p_SoDT      IN VARCHAR2,
    p_Email     IN VARCHAR2,
    p_TenPhong  IN VARCHAR2,
    p_Flag      IN NUMBER
)
AS
BEGIN
    IF p_Flag = 0 THEN
        UPDATE NhanVien
        SET TenNV     = p_TenNV,
            GioiTinh  = p_GioiTinh,
            DiaChi    = p_DiaChi,
            SoDT      = p_SoDT,
            Email     = p_Email,
            TenPhong  = p_TenPhong
        WHERE MaNV = p_MaNV;

        DBMS_OUTPUT.PUT_LINE('Cap nhat nhan vien thanh cong');
    ELSE
        INSERT INTO NhanVien(MaNV, TenNV, GioiTinh, DiaChi, SoDT, Email, TenPhong)
        VALUES(p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong);

        DBMS_OUTPUT.PUT_LINE('Them nhan vien thanh cong');
    END IF;
END;
/
SHOW ERRORS;

-- e. Thủ tục nhập dữ liệu bảng Nhap
CREATE OR REPLACE PROCEDURE sp_Nhap
(
    p_SoHDN     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayNhap  IN DATE,
    p_SoLuongN  IN NUMBER,
    p_DonGiaN   IN NUMBER
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_MaNV;

    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM PNhap
    WHERE SoHDN = p_SoHDN;

    IF v_count > 0 THEN
        UPDATE PNhap
        SET NgayNhap = p_NgayNhap,
            MaNV     = p_MaNV
        WHERE SoHDN = p_SoHDN;

        UPDATE Nhap
        SET SoLuongN = p_SoLuongN,
            DonGiaN  = p_DonGiaN
        WHERE SoHDN = p_SoHDN
          AND MaSP  = p_MaSP;

        DBMS_OUTPUT.PUT_LINE('Cap nhat phieu nhap thanh cong');
    ELSE
        INSERT INTO PNhap(SoHDN, NgayNhap, MaNV)
        VALUES(p_SoHDN, p_NgayNhap, p_MaNV);

        INSERT INTO Nhap(SoHDN, MaSP, SoLuongN, DonGiaN)
        VALUES(p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);

        DBMS_OUTPUT.PUT_LINE('Them phieu nhap thanh cong');
    END IF;
END;
/
SHOW ERRORS;

-- f. Thủ tục nhập dữ liệu bảng Xuat
CREATE OR REPLACE PROCEDURE sp_Xuat
(
    p_SoHDX     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayXuat  IN DATE,
    p_SoLuongX  IN NUMBER
)
AS
    v_count NUMBER;
    v_ton   NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_MaNV;

    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
        RETURN;
    END IF;

    SELECT SoLuong INTO v_ton
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF p_SoLuongX > v_ton THEN
        DBMS_OUTPUT.PUT_LINE('So luong xuat vuot qua so luong ton');
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM PXuat
    WHERE SoHDX = p_SoHDX;

    IF v_count > 0 THEN
        UPDATE PXuat
        SET NgayXuat = p_NgayXuat,
            MaNV     = p_MaNV
        WHERE SoHDX = p_SoHDX;

        UPDATE Xuat
        SET SoLuongX = p_SoLuongX
        WHERE SoHDX = p_SoHDX
          AND MaSP  = p_MaSP;

        DBMS_OUTPUT.PUT_LINE('Cap nhat phieu xuat thanh cong');
    ELSE
        INSERT INTO PXuat(SoHDX, NgayXuat, MaNV)
        VALUES(p_SoHDX, p_NgayXuat, p_MaNV);

        INSERT INTO Xuat(SoHDX, MaSP, SoLuongX)
        VALUES(p_SoHDX, p_MaSP, p_SoLuongX);

        DBMS_OUTPUT.PUT_LINE('Them phieu xuat thanh cong');
    END IF;
END;
/
SHOW ERRORS;

-- g. Thủ tục xóa NhanVien
CREATE OR REPLACE PROCEDURE sp_XoaNhanVien
(
    p_MaNV IN VARCHAR2
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_MaNV;

    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaNV khong ton tai');
        RETURN;
    END IF;

    DELETE FROM Nhap
    WHERE SoHDN IN (
        SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV
    );

    DELETE FROM PNhap
    WHERE MaNV = p_MaNV;

    DELETE FROM Xuat
    WHERE SoHDX IN (
        SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV
    );

    DELETE FROM PXuat
    WHERE MaNV = p_MaNV;

    DELETE FROM NhanVien
    WHERE MaNV = p_MaNV;

    DBMS_OUTPUT.PUT_LINE('Xoa nhan vien thanh cong');
END;
/
SHOW ERRORS;

-- h. Thủ tục xóa SanPham
CREATE OR REPLACE PROCEDURE sp_XoaSanPham
(
    p_MaSP IN VARCHAR2
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('MaSP khong ton tai');
        RETURN;
    END IF;

    DELETE FROM Nhap
    WHERE MaSP = p_MaSP;

    DELETE FROM Xuat
    WHERE MaSP = p_MaSP;

    DELETE FROM SanPham
    WHERE MaSP = p_MaSP;

    DBMS_OUTPUT.PUT_LINE('Xoa san pham thanh cong');
END;
/
SHOW ERRORS;

-- IV. PHIEU BAI TAP 2

-- a. Thủ tục sp_ThemNhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemNhanVien
(
    p_MaNV      IN VARCHAR2,
    p_TenNV     IN VARCHAR2,
    p_GioiTinh  IN VARCHAR2,
    p_DiaChi    IN VARCHAR2,
    p_SoDT      IN VARCHAR2,
    p_Email     IN VARCHAR2,
    p_TenPhong  IN VARCHAR2,
    p_Flag      IN NUMBER,
    p_KQ        OUT NUMBER
)
AS
BEGIN
    IF p_GioiTinh <> 'Nam' AND p_GioiTinh <> N'Nữ' THEN
        p_KQ := 1;
        RETURN;
    END IF;

    IF p_Flag = 0 THEN
        INSERT INTO NhanVien(MaNV, TenNV, GioiTinh, DiaChi, SoDT, Email, TenPhong)
        VALUES(p_MaNV, p_TenNV, p_GioiTinh, p_DiaChi, p_SoDT, p_Email, p_TenPhong);
    ELSE
        UPDATE NhanVien
        SET TenNV     = p_TenNV,
            GioiTinh  = p_GioiTinh,
            DiaChi    = p_DiaChi,
            SoDT      = p_SoDT,
            Email     = p_Email,
            TenPhong  = p_TenPhong
        WHERE MaNV = p_MaNV;
    END IF;

    p_KQ := 0;
END;
/
SHOW ERRORS;

-- b. Thủ tục sp_ThemMoiSP (có OUT)
CREATE OR REPLACE PROCEDURE sp_ThemMoiSP
(
    p_MaSP       IN VARCHAR2,
    p_TenHang    IN VARCHAR2,
    p_TenSP      IN VARCHAR2,
    p_SoLuong    IN NUMBER,
    p_MauSac     IN VARCHAR2,
    p_GiaBan     IN NUMBER,
    p_DonViTinh  IN VARCHAR2,
    p_MoTa       IN CLOB,
    p_Flag       IN NUMBER,
    p_KQ         OUT NUMBER
)
AS
    v_MaHangSX VARCHAR2(10);
BEGIN
    BEGIN
        SELECT MaHangSX INTO v_MaHangSX
        FROM HangSX
        WHERE TenHang = p_TenHang;
    EXCEPTION
        WHEN NO_DATA_FOUND THEN
            p_KQ := 1;
            RETURN;
    END;

    IF p_SoLuong < 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;

    IF p_Flag = 0 THEN
        INSERT INTO SanPham(MaSP, MaHangSX, TenSP, SoLuong, MauSac, GiaBan, DonViTinh, MoTa)
        VALUES(p_MaSP, v_MaHangSX, p_TenSP, p_SoLuong, p_MauSac, p_GiaBan, p_DonViTinh, p_MoTa);
    ELSE
        UPDATE SanPham
        SET MaHangSX  = v_MaHangSX,
            TenSP     = p_TenSP,
            SoLuong   = p_SoLuong,
            MauSac    = p_MauSac,
            GiaBan    = p_GiaBan,
            DonViTinh = p_DonViTinh,
            MoTa      = p_MoTa
        WHERE MaSP = p_MaSP;
    END IF;

    p_KQ := 0;
END;
/
SHOW ERRORS;

-- c. Thủ tục xóa NhanVien (có OUT)
CREATE OR REPLACE PROCEDURE sp_XoaNhanVien_OUT
(
    p_MaNV IN VARCHAR2,
    p_KQ   OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_MaNV;

    IF v_count = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;

    DELETE FROM Nhap
    WHERE SoHDN IN (
        SELECT SoHDN FROM PNhap WHERE MaNV = p_MaNV
    );

    DELETE FROM PNhap
    WHERE MaNV = p_MaNV;

    DELETE FROM Xuat
    WHERE SoHDX IN (
        SELECT SoHDX FROM PXuat WHERE MaNV = p_MaNV
    );

    DELETE FROM PXuat
    WHERE MaNV = p_MaNV;

    DELETE FROM NhanVien
    WHERE MaNV = p_MaNV;

    p_KQ := 0;
END;
/
SHOW ERRORS;

-- d. Thủ tục xóa SanPham (có OUT)
CREATE OR REPLACE PROCEDURE sp_XoaSanPham_OUT
(
    p_MaSP IN VARCHAR2,
    p_KQ   OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_count = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;

    DELETE FROM Nhap
    WHERE MaSP = p_MaSP;

    DELETE FROM Xuat
    WHERE MaSP = p_MaSP;

    DELETE FROM SanPham
    WHERE MaSP = p_MaSP;

    p_KQ := 0;
END;
/
SHOW ERRORS;

-- e. Thủ tục sp_NhapHangSX (có OUT)
CREATE OR REPLACE PROCEDURE sp_NhapHangSX_OUT
(
    p_MaHangSX IN VARCHAR2,
    p_TenHang  IN VARCHAR2,
    p_DiaChi   IN VARCHAR2,
    p_SoDT     IN VARCHAR2,
    p_Email    IN VARCHAR2,
    p_KQ       OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM HangSX
    WHERE TenHang = p_TenHang;

    IF v_count > 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;

    INSERT INTO HangSX(MaHangSX, TenHang, DiaChi, SoDT, Email)
    VALUES(p_MaHangSX, p_TenHang, p_DiaChi, p_SoDT, p_Email);

    p_KQ := 0;
END;
/
SHOW ERRORS;

-- f. Thủ tục nhập bảng Nhap (có OUT)
CREATE OR REPLACE PROCEDURE sp_Nhap_OUT
(
    p_SoHDN     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayNhap  IN DATE,
    p_SoLuongN  IN NUMBER,
    p_DonGiaN   IN NUMBER,
    p_KQ        OUT NUMBER
)
AS
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_count = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_MaNV;

    IF v_count = 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM PNhap
    WHERE SoHDN = p_SoHDN;

    IF v_count > 0 THEN
        UPDATE PNhap
        SET NgayNhap = p_NgayNhap,
            MaNV     = p_MaNV
        WHERE SoHDN = p_SoHDN;

        UPDATE Nhap
        SET SoLuongN = p_SoLuongN,
            DonGiaN  = p_DonGiaN
        WHERE SoHDN = p_SoHDN
          AND MaSP  = p_MaSP;
    ELSE
        INSERT INTO PNhap(SoHDN, NgayNhap, MaNV)
        VALUES(p_SoHDN, p_NgayNhap, p_MaNV);

        INSERT INTO Nhap(SoHDN, MaSP, SoLuongN, DonGiaN)
        VALUES(p_SoHDN, p_MaSP, p_SoLuongN, p_DonGiaN);
    END IF;

    p_KQ := 0;
END;
/
SHOW ERRORS;

-- g. Thủ tục nhập bảng Xuat (có OUT)
CREATE OR REPLACE PROCEDURE sp_Xuat_OUT
(
    p_SoHDX     IN VARCHAR2,
    p_MaSP      IN VARCHAR2,
    p_MaNV      IN VARCHAR2,
    p_NgayXuat  IN DATE,
    p_SoLuongX  IN NUMBER,
    p_KQ        OUT NUMBER
)
AS
    v_count NUMBER;
    v_ton   NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF v_count = 0 THEN
        p_KQ := 1;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM NhanVien
    WHERE MaNV = p_MaNV;

    IF v_count = 0 THEN
        p_KQ := 2;
        RETURN;
    END IF;

    SELECT SoLuong INTO v_ton
    FROM SanPham
    WHERE MaSP = p_MaSP;

    IF p_SoLuongX > v_ton THEN
        p_KQ := 3;
        RETURN;
    END IF;

    SELECT COUNT(*) INTO v_count
    FROM PXuat
    WHERE SoHDX = p_SoHDX;

    IF v_count > 0 THEN
        UPDATE PXuat
        SET NgayXuat = p_NgayXuat,
            MaNV     = p_MaNV
        WHERE SoHDX = p_SoHDX;

        UPDATE Xuat
        SET SoLuongX = p_SoLuongX
        WHERE SoHDX = p_SoHDX
          AND MaSP  = p_MaSP;
    ELSE
        INSERT INTO PXuat(SoHDX, NgayXuat, MaNV)
        VALUES(p_SoHDX, p_NgayXuat, p_MaNV);

        INSERT INTO Xuat(SoHDX, MaSP, SoLuongX)
        VALUES(p_SoHDX, p_MaSP, p_SoLuongX);
    END IF;

    p_KQ := 0;
END;
/
SHOW ERRORS;

-- TEST DU LIEU KHONG CO OUT

BEGIN
    sp_NhapHangSX('H01', 'Apple', 'Ha Noi', '0900000001', 'apple@gmail.com');
END;
/
BEGIN
    sp_NhapHangSX('H02', 'Samsung', 'TP HCM', '0900000002', 'samsung@gmail.com');
END;
/
BEGIN
    sp_NhapNhanVien('NV01', 'Nguyen Van A', 'Nam', 'Ha Noi', '0911111111', 'nva@gmail.com', 'KeToan', 1);
END;
/
BEGIN
    sp_NhapNhanVien('NV02', 'Tran Thi B', N'Nữ', 'Hai Phong', '0922222222', 'ttb@gmail.com', 'BanHang', 1);
END;
/
BEGIN
    sp_NhapSP('SP01', 'Apple', 'Iphone 15', 50, 'Den', 25000000, 'Chiec', 'Dien thoai Apple');
END;
/
BEGIN
    sp_NhapSP('SP02', 'Samsung', 'Galaxy S24', 40, 'Trang', 22000000, 'Chiec', 'Dien thoai Samsung');
END;
/
BEGIN
    sp_Nhap('N01', 'SP01', 'NV01', SYSDATE, 10, 20000000);
END;
/
BEGIN
    sp_Xuat('X01', 'SP01', 'NV01', SYSDATE, 5);
END;
/

-- TEST THU TUC CO OUT

DECLARE
    v_kq NUMBER;
BEGIN
    sp_NhapHangSX_OUT('H10', 'Xiaomi', 'Da Nang', '0123456789', 'xiaomi@gmail.com', v_kq);
    DBMS_OUTPUT.PUT_LINE('sp_NhapHangSX_OUT -> KQ = ' || v_kq);
END;
/
 
DECLARE
    v_kq NUMBER;
BEGIN
    sp_ThemNhanVien('NV10', 'Le Van C', 'Nam', 'Hue', '0988888888', 'c@gmail.com', 'KeToan', 0, v_kq);
    DBMS_OUTPUT.PUT_LINE('sp_ThemNhanVien -> KQ = ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_ThemMoiSP('SP10', 'Xiaomi', 'Redmi Note', 20, 'Den', 7000000, 'Chiec', 'Mo ta SP', 0, v_kq);
    DBMS_OUTPUT.PUT_LINE('sp_ThemMoiSP -> KQ = ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_Nhap_OUT('N10', 'SP10', 'NV10', SYSDATE, 5, 6000000, v_kq);
    DBMS_OUTPUT.PUT_LINE('sp_Nhap_OUT -> KQ = ' || v_kq);
END;
/

DECLARE
    v_kq NUMBER;
BEGIN
    sp_Xuat_OUT('X10', 'SP10', 'NV10', SYSDATE, 2, v_kq);
    DBMS_OUTPUT.PUT_LINE('sp_Xuat_OUT -> KQ = ' || v_kq);
END;
/

-- KIEM TRA DU LIEU

SELECT * FROM HangSX;
SELECT * FROM NhanVien;
SELECT * FROM SanPham;
SELECT * FROM PNhap;
SELECT * FROM Nhap;
SELECT * FROM PXuat;
SELECT * FROM Xuat;