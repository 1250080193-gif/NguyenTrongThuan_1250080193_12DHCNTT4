SET SERVEROUTPUT ON;

-- DROP TABLE (neu co)
BEGIN EXECUTE IMMEDIATE 'DROP TABLE s_item'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE s_ord'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE s_product'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE s_customer'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE s_emp'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE s_dept'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE s_region'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- BAI 1: CREATE TABLE
CREATE TABLE s_region (
 id NUMBER PRIMARY KEY,
 name VARCHAR2(50) NOT NULL
);

CREATE TABLE s_dept (
 id NUMBER PRIMARY KEY,
 name VARCHAR2(50),
 region_id NUMBER,
 FOREIGN KEY (region_id) REFERENCES s_region(id)
);

CREATE TABLE s_emp (
 id NUMBER PRIMARY KEY,
 last_name VARCHAR2(50),
 first_name VARCHAR2(50),
 userid VARCHAR2(20),
 start_date DATE,
 manager_id NUMBER,
 title VARCHAR2(50),
 dept_id NUMBER,
 salary NUMBER,
 commission_pct NUMBER,
 FOREIGN KEY (dept_id) REFERENCES s_dept(id)
);

CREATE TABLE s_customer (
 id NUMBER PRIMARY KEY,
 name VARCHAR2(100),
 phone VARCHAR2(20),
 region_id NUMBER
);

CREATE TABLE s_product (
 id NUMBER PRIMARY KEY,
 name VARCHAR2(100),
 short_desc VARCHAR2(200)
);

CREATE TABLE s_ord (
 id NUMBER PRIMARY KEY,
 customer_id NUMBER,
 date_ordered DATE,
 total NUMBER,
 FOREIGN KEY (customer_id) REFERENCES s_customer(id)
);

CREATE TABLE s_item (
 ord_id NUMBER,
 item_id NUMBER,
 product_id NUMBER,
 price NUMBER,
 quantity NUMBER,
 PRIMARY KEY (ord_id, item_id),
 FOREIGN KEY (ord_id) REFERENCES s_ord(id),
 FOREIGN KEY (product_id) REFERENCES s_product(id)
);

-- REGION
INSERT INTO s_region VALUES (4,'Dong Bac');
INSERT INTO s_region VALUES (5,'Tay Bac');
INSERT INTO s_region VALUES (6,'Bac Trung Bo');
INSERT INTO s_region VALUES (7,'Nam Trung Bo');
INSERT INTO s_region VALUES (8,'Dong Nam Bo');
INSERT INTO s_region VALUES (9,'Tay Nam Bo');
INSERT INTO s_region VALUES (10,'Ha Noi');
INSERT INTO s_region VALUES (11,'TP HCM');
INSERT INTO s_region VALUES (12,'Da Nang');
INSERT INTO s_region VALUES (13,'Hai Phong');
INSERT INTO s_region VALUES (14,'Can Tho');
INSERT INTO s_region VALUES (15,'Hue');
INSERT INTO s_region VALUES (16,'Quang Ninh');
INSERT INTO s_region VALUES (17,'Nghe An');
INSERT INTO s_region VALUES (18,'Binh Duong');
INSERT INTO s_region VALUES (19,'Dong Nai');
INSERT INTO s_region VALUES (20,'Long An');
INSERT INTO s_region VALUES (21,'An Giang');
INSERT INTO s_region VALUES (22,'Vung Tau');
INSERT INTO s_region VALUES (23,'Phu Quoc');

-- DEPT 
INSERT INTO s_dept VALUES (60,'Ban hang 1',4);
INSERT INTO s_dept VALUES (61,'Ban hang 2',5);
INSERT INTO s_dept VALUES (62,'IT 1',6);
INSERT INTO s_dept VALUES (63,'IT 2',7);
INSERT INTO s_dept VALUES (64,'HR 1',8);
INSERT INTO s_dept VALUES (65,'HR 2',9);
INSERT INTO s_dept VALUES (66,'Marketing 1',10);
INSERT INTO s_dept VALUES (67,'Marketing 2',11);
INSERT INTO s_dept VALUES (68,'Tai chinh 1',12);
INSERT INTO s_dept VALUES (69,'Tai chinh 2',13);
INSERT INTO s_dept VALUES (70,'Kinh doanh 3',14);
INSERT INTO s_dept VALUES (71,'Kinh doanh 4',15);
INSERT INTO s_dept VALUES (72,'IT 3',16);
INSERT INTO s_dept VALUES (73,'IT 4',17);
INSERT INTO s_dept VALUES (74,'HR 3',18);
INSERT INTO s_dept VALUES (75,'HR 4',19);
INSERT INTO s_dept VALUES (76,'Marketing 3',20);
INSERT INTO s_dept VALUES (77,'Marketing 4',21);
INSERT INTO s_dept VALUES (78,'Tai chinh 3',22);
INSERT INTO s_dept VALUES (79,'Tai chinh 4',23);

-- EMP
INSERT INTO s_emp VALUES (20,'Nguyen','A','a20',DATE '1991-01-01',1,'Staff',60,1800,NULL);
INSERT INTO s_emp VALUES (21,'Tran','B','b21',DATE '1992-02-02',1,'Staff',61,1900,NULL);
INSERT INTO s_emp VALUES (22,'Le','C','c22',DATE '1993-03-03',1,'Staff',62,2000,NULL);
INSERT INTO s_emp VALUES (23,'Pham','D','d23',DATE '1990-04-04',2,'Staff',63,2100,NULL);
INSERT INTO s_emp VALUES (24,'Hoang','E','e24',DATE '1991-05-05',2,'Staff',64,2200,NULL);
INSERT INTO s_emp VALUES (25,'Do','F','f25',DATE '1992-06-06',2,'Staff',65,2300,NULL);
INSERT INTO s_emp VALUES (26,'Vu','G','g26',DATE '1993-07-07',6,'Staff',66,2400,NULL);
INSERT INTO s_emp VALUES (27,'Nguyen','H','h27',DATE '1991-08-08',6,'Staff',67,2500,NULL);
INSERT INTO s_emp VALUES (28,'Tran','I','i28',DATE '1992-09-09',6,'Staff',68,2600,NULL);
INSERT INTO s_emp VALUES (29,'Le','K','k29',DATE '1993-10-10',6,'Staff',69,2700,NULL);
INSERT INTO s_emp VALUES (30,'Pham','L','l30',DATE '1991-11-11',1,'Staff',70,2800,NULL);
INSERT INTO s_emp VALUES (31,'Hoang','M','m31',DATE '1992-12-12',1,'Staff',71,2900,NULL);
INSERT INTO s_emp VALUES (32,'Do','N','n32',DATE '1993-01-01',1,'Staff',72,3000,NULL);
INSERT INTO s_emp VALUES (33,'Vu','O','o33',DATE '1991-02-02',2,'Staff',73,1800,NULL);
INSERT INTO s_emp VALUES (34,'Nguyen','P','p34',DATE '1992-03-03',2,'Staff',74,1900,NULL);
INSERT INTO s_emp VALUES (35,'Tran','Q','q35',DATE '1993-04-04',2,'Staff',75,2000,NULL);
INSERT INTO s_emp VALUES (36,'Le','R','r36',DATE '1991-05-05',6,'Staff',76,2100,NULL);
INSERT INTO s_emp VALUES (37,'Pham','S','s37',DATE '1992-06-06',6,'Staff',77,2200,NULL);
INSERT INTO s_emp VALUES (38,'Hoang','T','t38',DATE '1993-07-07',6,'Staff',78,2300,NULL);
INSERT INTO s_emp VALUES (39,'Do','U','u39',DATE '1991-08-08',6,'Staff',79,2400,NULL);
INSERT INTO s_emp VALUES (300,'Tran','B','b300',DATE '1991-01-01',1,'Staff',60,1800,NULL);

-- CUSTOMER 
INSERT INTO s_customer VALUES (200,'Cong ty A','0900000001',4);
INSERT INTO s_customer VALUES (201,'Cong ty B','0900000002',5);
INSERT INTO s_customer VALUES (202,'Cong ty C','0900000003',6);
INSERT INTO s_customer VALUES (203,'Cong ty D','0900000004',7);
INSERT INTO s_customer VALUES (204,'Cong ty E','0900000005',8);
INSERT INTO s_customer VALUES (205,'Cong ty F','0900000006',9);
INSERT INTO s_customer VALUES (206,'Cong ty G','0900000007',10);
INSERT INTO s_customer VALUES (207,'Cong ty H','0900000008',11);
INSERT INTO s_customer VALUES (208,'Cong ty I','0900000009',12);
INSERT INTO s_customer VALUES (209,'Cong ty K','0900000010',13);
INSERT INTO s_customer VALUES (210,'Cong ty L','0900000011',14);
INSERT INTO s_customer VALUES (211,'Cong ty M','0900000012',15);
INSERT INTO s_customer VALUES (212,'Cong ty N','0900000013',16);
INSERT INTO s_customer VALUES (213,'Cong ty O','0900000014',17);
INSERT INTO s_customer VALUES (214,'Cong ty P','0900000015',18);
INSERT INTO s_customer VALUES (215,'Cong ty Q','0900000016',19);
INSERT INTO s_customer VALUES (216,'Cong ty R','0900000017',20);
INSERT INTO s_customer VALUES (217,'Cong ty S','0900000018',21);
INSERT INTO s_customer VALUES (218,'Cong ty T','0900000019',22);
INSERT INTO s_customer VALUES (219,'Cong ty U','0900000020',23);
INSERT INTO s_customer VALUES (999,'Cong ty Chua Dat','0999999999',1);

-- PRODUCT
INSERT INTO s_product VALUES (300,'Xe dap 1','Xe dap thuong');
INSERT INTO s_product VALUES (301,'Xe dap 2','Xe dap dia hinh');
INSERT INTO s_product VALUES (302,'Ski 1','Dung cu ski');
INSERT INTO s_product VALUES (303,'Ski 2','Ski chuyen nghiep');
INSERT INTO s_product VALUES (304,'Ao the thao','Ao chay bo');
INSERT INTO s_product VALUES (305,'Quan the thao','Quan tap gym');
INSERT INTO s_product VALUES (306,'Giay 1','Giay chay');
INSERT INTO s_product VALUES (307,'Giay 2','Giay tap gym');
INSERT INTO s_product VALUES (308,'Gang tay','Gang tay the thao');
INSERT INTO s_product VALUES (309,'Mu 1','Mu bao hiem');
INSERT INTO s_product VALUES (310,'Mu 2','Mu the thao');
INSERT INTO s_product VALUES (311,'Balo 1','Balo du lich');
INSERT INTO s_product VALUES (312,'Balo 2','Balo the thao');
INSERT INTO s_product VALUES (313,'Kinh 1','Kinh bao ho');
INSERT INTO s_product VALUES (314,'Kinh 2','Kinh chong bui');
INSERT INTO s_product VALUES (315,'Ao khoac','Ao khoac Pro');
INSERT INTO s_product VALUES (316,'Quan jeans','Quan mac hang ngay');
INSERT INTO s_product VALUES (317,'Giay da','Giay cong so');
INSERT INTO s_product VALUES (318,'Dep','Dep di trong nha');
INSERT INTO s_product VALUES (319,'Tat','Tat the thao');

-- ORD
INSERT INTO s_ord VALUES (400,200,DATE '2023-01-01',100000);
INSERT INTO s_ord VALUES (401,201,DATE '2023-01-02',120000);
INSERT INTO s_ord VALUES (402,202,DATE '2023-01-03',140000);
INSERT INTO s_ord VALUES (403,203,DATE '2023-01-04',160000);
INSERT INTO s_ord VALUES (404,204,DATE '2023-01-05',180000);
INSERT INTO s_ord VALUES (405,205,DATE '2023-01-06',200000);
INSERT INTO s_ord VALUES (406,206,DATE '2023-01-07',220000);
INSERT INTO s_ord VALUES (407,207,DATE '2023-01-08',240000);
INSERT INTO s_ord VALUES (408,208,DATE '2023-01-09',260000);
INSERT INTO s_ord VALUES (409,209,DATE '2023-01-10',280000);
INSERT INTO s_ord VALUES (410,210,DATE '2023-01-11',300000);
INSERT INTO s_ord VALUES (411,211,DATE '2023-01-12',320000);
INSERT INTO s_ord VALUES (412,212,DATE '2023-01-13',340000);
INSERT INTO s_ord VALUES (413,213,DATE '2023-01-14',360000);
INSERT INTO s_ord VALUES (414,214,DATE '2023-01-15',380000);
INSERT INTO s_ord VALUES (415,215,DATE '2023-01-16',400000);
INSERT INTO s_ord VALUES (416,216,DATE '2023-01-17',420000);
INSERT INTO s_ord VALUES (417,217,DATE '2023-01-18',440000);
INSERT INTO s_ord VALUES (418,218,DATE '2023-01-19',460000);
INSERT INTO s_ord VALUES (419,219,DATE '2023-01-20',480000);

-- ITEM 
INSERT INTO s_item VALUES (400,1,300,1000,2);
INSERT INTO s_item VALUES (401,1,301,1200,3);
INSERT INTO s_item VALUES (402,1,302,1400,4);
INSERT INTO s_item VALUES (403,1,303,1600,5);
INSERT INTO s_item VALUES (404,1,304,1800,6);
INSERT INTO s_item VALUES (405,1,305,2000,7);
INSERT INTO s_item VALUES (406,1,306,2200,8);
INSERT INTO s_item VALUES (407,1,307,2400,9);
INSERT INTO s_item VALUES (408,1,308,2600,10);
INSERT INTO s_item VALUES (409,1,309,2800,2);
INSERT INTO s_item VALUES (410,1,310,3000,3);
INSERT INTO s_item VALUES (411,1,311,3200,4);
INSERT INTO s_item VALUES (412,1,312,3400,5);
INSERT INTO s_item VALUES (413,1,313,3600,6);
INSERT INTO s_item VALUES (414,1,314,3800,7);
INSERT INTO s_item VALUES (415,1,315,4000,8);
INSERT INTO s_item VALUES (416,1,316,4200,9);
INSERT INTO s_item VALUES (417,1,317,4400,10);
INSERT INTO s_item VALUES (418,1,318,4600,2);
INSERT INTO s_item VALUES (419,1,319,4800,3);

COMMIT;

-- BAI 2: SELECT
-- Câu 1
SELECT name AS "Ten khach hang", id AS "Ma khach hang"
FROM s_customer
ORDER BY id DESC;

-- Câu 2 
SELECT first_name || ' ' || last_name AS "Employees", dept_id
FROM s_emp
WHERE dept_id IN (60,61)
ORDER BY first_name;

-- Câu 3
SELECT last_name, first_name
FROM s_emp
WHERE first_name LIKE '%S%' OR last_name LIKE '%S%';

-- Câu 4
SELECT userid, start_date
FROM s_emp
WHERE start_date BETWEEN TO_DATE('14/05/1990','DD/MM/YYYY')
AND TO_DATE('26/05/1991','DD/MM/YYYY');

-- Câu 5
SELECT last_name, salary
FROM s_emp
WHERE salary BETWEEN 1000 AND 2000;

-- Câu 6
SELECT last_name || ' ' || first_name AS "Employee Name",
       salary AS "Monthly Salary"
FROM s_emp
WHERE dept_id IN (60,61,62) AND salary > 1350;

-- Câu 7
SELECT last_name, start_date
FROM s_emp
WHERE TO_CHAR(start_date,'YYYY') = '1991';

-- Câu 8
SELECT last_name, first_name
FROM s_emp
WHERE id NOT IN (
 SELECT manager_id FROM s_emp WHERE manager_id IS NOT NULL
);

-- Câu 9
SELECT name 
FROM s_product 
WHERE name LIKE '%Xe%' 
ORDER BY name;

-- Câu 10
SELECT name, short_desc
FROM s_product
WHERE LOWER(short_desc) LIKE '%dap%';

-- Câu 11
SELECT short_desc FROM s_product;

-- Câu 12
SELECT last_name || ' ' || first_name || ' (' || title || ')' AS "Nhan vien"
FROM s_emp;

-- BÀI 3: HÀM
-- Câu 1
SELECT id, last_name,
       ROUND(salary * 1.15,2) AS "Luong moi"
FROM s_emp;

-- Câu 2
SELECT last_name,
       start_date,
       TO_CHAR(
         NEXT_DAY(ADD_MONTHS(start_date,6),'MONDAY'),
         'Ddspth "of" Month YYYY'
       ) AS "Ngay xet tang luong"
FROM s_emp;

-- Câu 3
SELECT name
FROM s_product
WHERE LOWER(name) LIKE '%ski%';

-- Câu 4
SELECT last_name,
       ROUND(MONTHS_BETWEEN(SYSDATE,start_date)) AS "So thang"
FROM s_emp
ORDER BY MONTHS_BETWEEN(SYSDATE,start_date);

-- Câu 5
SELECT COUNT(DISTINCT manager_id) AS "So nguoi quan ly"
FROM s_emp
WHERE manager_id IS NOT NULL;

-- Câu 6
SELECT MAX(total) AS "Highest",
       MIN(total) AS "Lowest"
FROM s_ord;

-- BÀI 4: JOIN
-- Câu 1 
SELECT p.name, p.id,
       i.quantity AS "ORDERED"
FROM s_product p, s_item i
WHERE p.id = i.product_id
  AND i.ord_id = 400;

-- Câu 2
SELECT c.id AS "Ma khach hang",
       o.id AS "Ma don hang"
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id(+)
ORDER BY c.id;

-- Câu 3
SELECT o.customer_id,
       i.product_id,
       i.quantity
FROM s_ord o, s_item i
WHERE o.id = i.ord_id
  AND o.total > 100000;

-- BÀI 5: GROUP BY
-- Câu 1
SELECT manager_id,
       COUNT(id) AS "So NV"
FROM s_emp
WHERE manager_id IS NOT NULL
GROUP BY manager_id;

-- Câu 2 
SELECT manager_id,
       COUNT(id)
FROM s_emp
WHERE manager_id IS NOT NULL
GROUP BY manager_id
HAVING COUNT(id) >= 1;

-- Câu 3
SELECT r.id, r.name,
       COUNT(d.id)
FROM s_region r, s_dept d
WHERE r.id = d.region_id
GROUP BY r.id, r.name;

-- Câu 4
SELECT c.name,
       COUNT(o.id)
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name;

-- Câu 5 
SELECT c.name, COUNT(o.id)
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
HAVING COUNT(o.id) = (
    SELECT MAX(cnt)
    FROM (
        SELECT COUNT(id) cnt
        FROM s_ord
        GROUP BY customer_id
    )
);

-- Câu 6
SELECT c.name, SUM(o.total)
FROM s_customer c, s_ord o
WHERE c.id = o.customer_id
GROUP BY c.id, c.name
HAVING SUM(o.total) = (
    SELECT MAX(total_sum)
    FROM (
        SELECT SUM(total) total_sum
        FROM s_ord
        GROUP BY customer_id
    )
);

-- BÀI 6: SUBQUERY
-- Câu 1
SELECT last_name, first_name, start_date
FROM s_emp
WHERE dept_id = (
    SELECT dept_id FROM s_emp WHERE first_name = 'A'
)
AND first_name <> 'A';

-- Câu 2
SELECT id, last_name, first_name, userid
FROM s_emp
WHERE salary > (SELECT AVG(salary) FROM s_emp);

-- Câu 3
SELECT id, last_name, first_name
FROM s_emp
WHERE salary > (SELECT AVG(salary) FROM s_emp)
AND (UPPER(first_name) LIKE '%L%' OR UPPER(last_name) LIKE '%L%');

-- Câu 4
SELECT name
FROM s_customer
WHERE id NOT IN (
    SELECT customer_id
    FROM s_ord
    WHERE customer_id IS NOT NULL
);