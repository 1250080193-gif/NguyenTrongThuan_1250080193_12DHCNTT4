SET SERVEROUTPUT ON;

--------------------------------------------------------------------------------
-- PHIẾU 1: KHOA, LOP
--------------------------------------------------------------------------------
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE LOP';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE KHOA';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

CREATE TABLE KHOA (
  Makhoa    VARCHAR2(10) PRIMARY KEY,
  Tenkhoa   VARCHAR2(100) NOT NULL,
  Dienthoai VARCHAR2(20)
);

CREATE TABLE LOP (
  Malop       VARCHAR2(10) PRIMARY KEY,
  Tenlop      VARCHAR2(100) NOT NULL,
  Khoa        VARCHAR2(50),
  Hedt        VARCHAR2(50),
  Namnhaphoc  NUMBER(4),
  Makhoa      VARCHAR2(10),
  CONSTRAINT fk_lop_khoa FOREIGN KEY (Makhoa) REFERENCES KHOA(Makhoa)
);

-- BÀI 1: Thêm KHOA, kiểm tra Tenkhoa tồn tại -> thông báo
CREATE OR REPLACE PROCEDURE sp_them_khoa_bt1 (
  p_makhoa    IN KHOA.Makhoa%TYPE,
  p_tenkhoa   IN KHOA.Tenkhoa%TYPE,
  p_dienthoai IN KHOA.Dienthoai%TYPE
)
AS
  v_dem NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem
  FROM KHOA
  WHERE UPPER(Tenkhoa) = UPPER(p_tenkhoa);

  IF v_dem > 0 THEN
    DBMS_OUTPUT.PUT_LINE('BT1: Ten khoa da ton tai!');
  ELSE
    INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai)
    VALUES (p_makhoa, p_tenkhoa, p_dienthoai);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('BT1: Them khoa thanh cong!');
  END IF;
END;
/
SHOW ERRORS;

-- BÀI 2: Thêm LOP, kiểm tra Tenlop trùng + Makhoa tồn tại
CREATE OR REPLACE PROCEDURE sp_them_lop_bt2 (
  p_malop      IN LOP.Malop%TYPE,
  p_tenlop     IN LOP.Tenlop%TYPE,
  p_khoa       IN LOP.Khoa%TYPE,
  p_hedt       IN LOP.Hedt%TYPE,
  p_namnhaphoc IN LOP.Namnhaphoc%TYPE,
  p_makhoa     IN LOP.Makhoa%TYPE
)
AS
  v_dem_lop  NUMBER := 0;
  v_dem_khoa NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_lop
  FROM LOP
  WHERE UPPER(Tenlop) = UPPER(p_tenlop);

  IF v_dem_lop > 0 THEN
    DBMS_OUTPUT.PUT_LINE('BT2: Ten lop da ton tai!');
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_dem_khoa
  FROM KHOA
  WHERE Makhoa = p_makhoa;

  IF v_dem_khoa = 0 THEN
    DBMS_OUTPUT.PUT_LINE('BT2: Makhoa khong ton tai trong KHOA!');
    RETURN;
  END IF;

  INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa)
  VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('BT2: Them lop thanh cong!');
END;
/
SHOW ERRORS;

-- BÀI 3: Thêm KHOA, nếu tên khoa tồn tại -> OUT=0, ngược lại insert
CREATE OR REPLACE PROCEDURE sp_them_khoa_bt3 (
  p_makhoa    IN KHOA.Makhoa%TYPE,
  p_tenkhoa   IN KHOA.Tenkhoa%TYPE,
  p_dienthoai IN KHOA.Dienthoai%TYPE,
  p_ketqua    OUT NUMBER
)
AS
  v_dem NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem
  FROM KHOA
  WHERE UPPER(Tenkhoa) = UPPER(p_tenkhoa);

  IF v_dem > 0 THEN
    p_ketqua := 0;
    RETURN;
  END IF;

  INSERT INTO KHOA(Makhoa, Tenkhoa, Dienthoai)
  VALUES (p_makhoa, p_tenkhoa, p_dienthoai);

  COMMIT;
  p_ketqua := 1;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_ketqua := -1;
END;
/
SHOW ERRORS;

-- BÀI 4: Thêm LOP trả mã: trùng tên lớp ->0, Makhoa không có ->1, OK ->2
CREATE OR REPLACE PROCEDURE sp_them_lop_bt4 (
  p_malop      IN LOP.Malop%TYPE,
  p_tenlop     IN LOP.Tenlop%TYPE,
  p_khoa       IN LOP.Khoa%TYPE,
  p_hedt       IN LOP.Hedt%TYPE,
  p_namnhaphoc IN LOP.Namnhaphoc%TYPE,
  p_makhoa     IN LOP.Makhoa%TYPE,
  p_ketqua     OUT NUMBER
)
AS
  v_dem_lop  NUMBER := 0;
  v_dem_khoa NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_lop
  FROM LOP
  WHERE UPPER(Tenlop) = UPPER(p_tenlop);

  IF v_dem_lop > 0 THEN
    p_ketqua := 0;
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_dem_khoa
  FROM KHOA
  WHERE Makhoa = p_makhoa;

  IF v_dem_khoa = 0 THEN
    p_ketqua := 1;
    RETURN;
  END IF;

  INSERT INTO LOP(Malop, Tenlop, Khoa, Hedt, Namnhaphoc, Makhoa)
  VALUES (p_malop, p_tenlop, p_khoa, p_hedt, p_namnhaphoc, p_makhoa);

  COMMIT;
  p_ketqua := 2;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_ketqua := -1;
END;
/
SHOW ERRORS;

--------------------------------------------------------------------------------
-- TEST PHIẾU 1
--------------------------------------------------------------------------------
BEGIN
  sp_them_khoa_bt1('K01','Cong nghe thong tin','0901');
  sp_them_khoa_bt1('K02','Cong nghe thong tin','0902'); -- trùng tên
END;
/

DECLARE v_kq NUMBER;
BEGIN
  sp_them_khoa_bt3('K03','Dien tu','0999', v_kq);
  DBMS_OUTPUT.PUT_LINE('BT3 KQ='||v_kq);

  sp_them_khoa_bt3('K04','Dien tu','0888', v_kq); -- trùng tên ->0
  DBMS_OUTPUT.PUT_LINE('BT3 KQ='||v_kq);
END;
/

BEGIN
  sp_them_lop_bt2('L01','CNTT1','Khoa A','Chinh quy',2024,'K01'); -- ok
  sp_them_lop_bt2('L02','CNTT1','Khoa A','Chinh quy',2024,'K01'); -- trùng tên lớp
  sp_them_lop_bt2('L03','CNTT2','Khoa A','Chinh quy',2024,'KXX'); -- makhoa không tồn tại
END;
/

DECLARE v_kq NUMBER;
BEGIN
  sp_them_lop_bt4('L04','CNTT3','Khoa A','Chinh quy',2024,'KXX', v_kq);
  DBMS_OUTPUT.PUT_LINE('BT4 KQ='||v_kq); -- 1

  sp_them_lop_bt4('L05','CNTT1','Khoa A','Chinh quy',2024,'K01', v_kq);
  DBMS_OUTPUT.PUT_LINE('BT4 KQ='||v_kq); -- 0 (trùng tên lớp)

  sp_them_lop_bt4('L06','CNTT4','Khoa A','Chinh quy',2024,'K01', v_kq);
  DBMS_OUTPUT.PUT_LINE('BT4 KQ='||v_kq); -- 2
END;
/

--------------------------------------------------------------------------------
-- PHIẾU 2 + 3: QLNV (tblChucVu, tblNhanVien)
--------------------------------------------------------------------------------
BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE tblNhanVien';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
  EXECUTE IMMEDIATE 'DROP TABLE tblChucVu';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

CREATE TABLE tblChucVu (
  MaCV  VARCHAR2(10) PRIMARY KEY,
  TenCV VARCHAR2(100) NOT NULL
);

CREATE TABLE tblNhanVien (
  MaNV        VARCHAR2(10) PRIMARY KEY,
  MaCV        VARCHAR2(10) NOT NULL,
  TenNV       VARCHAR2(100) NOT NULL,
  NgaySinh    DATE,
  LuongCanBan NUMBER(12,0),
  NgayCong    NUMBER(5,0),
  PhuCap      NUMBER(12,0),
  CONSTRAINT fk_nv_cv FOREIGN KEY (MaCV) REFERENCES tblChucVu(MaCV)
);

-- Dữ liệu mẫu
INSERT INTO tblChucVu VALUES ('CV01','Giam doc');
INSERT INTO tblChucVu VALUES ('CV02','Truong phong');
INSERT INTO tblChucVu VALUES ('CV03','Nhan vien');
INSERT INTO tblChucVu VALUES ('CV04','Thuc tap');

INSERT INTO tblNhanVien VALUES ('NV01','CV01','Nguyen A',TO_DATE('01/01/1990','DD/MM/YYYY'),10000000,26,2000000);
INSERT INTO tblNhanVien VALUES ('NV02','CV03','Tran B',  TO_DATE('02/02/1995','DD/MM/YYYY'), 7000000,24, 800000);
INSERT INTO tblNhanVien VALUES ('NV03','CV02','Le C',    TO_DATE('03/03/1992','DD/MM/YYYY'), 9000000,25,1500000);
COMMIT;

-- PHIẾU 2a: SP_Them_Nhan_Vien (kiểm tra MaCV tồn tại)
CREATE OR REPLACE PROCEDURE SP_Them_Nhan_Vien (
  p_MaNV        IN tblNhanVien.MaNV%TYPE,
  p_MaCV        IN tblNhanVien.MaCV%TYPE,
  p_TenNV       IN tblNhanVien.TenNV%TYPE,
  p_NgaySinh    IN tblNhanVien.NgaySinh%TYPE,
  p_LuongCanBan IN tblNhanVien.LuongCanBan%TYPE,
  p_NgayCong    IN tblNhanVien.NgayCong%TYPE,
  p_PhuCap      IN tblNhanVien.PhuCap%TYPE
)
AS
  v_dem NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem FROM tblChucVu WHERE MaCV = p_MaCV;
  IF v_dem = 0 THEN
    DBMS_OUTPUT.PUT_LINE('P2a: MaCV khong ton tai -> Khong them duoc!');
    RETURN;
  END IF;

  INSERT INTO tblNhanVien(MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap)
  VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh, p_LuongCanBan, p_NgayCong, p_PhuCap);

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('P2a: Them nhan vien thanh cong!');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('P2a Loi: ' || SQLERRM);
END;
/
SHOW ERRORS;

-- PHIẾU 2b: SP_CapNhat_Nhan_Vien (không đổi MaNV, kiểm tra MaCV)
CREATE OR REPLACE PROCEDURE SP_CapNhat_Nhan_Vien (
  p_MaNV        IN tblNhanVien.MaNV%TYPE,
  p_MaCV        IN tblNhanVien.MaCV%TYPE,
  p_TenNV       IN tblNhanVien.TenNV%TYPE,
  p_NgaySinh    IN tblNhanVien.NgaySinh%TYPE,
  p_LuongCanBan IN tblNhanVien.LuongCanBan%TYPE,
  p_NgayCong    IN tblNhanVien.NgayCong%TYPE,
  p_PhuCap      IN tblNhanVien.PhuCap%TYPE
)
AS
  v_dem_cv NUMBER := 0;
  v_dem_nv NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_nv FROM tblNhanVien WHERE MaNV = p_MaNV;
  IF v_dem_nv = 0 THEN
    DBMS_OUTPUT.PUT_LINE('P2b: Khong tim thay MaNV -> Khong cap nhat!');
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_dem_cv FROM tblChucVu WHERE MaCV = p_MaCV;
  IF v_dem_cv = 0 THEN
    DBMS_OUTPUT.PUT_LINE('P2b: MaCV khong ton tai -> Khong cap nhat!');
    RETURN;
  END IF;

  UPDATE tblNhanVien
  SET MaCV = p_MaCV,
      TenNV = p_TenNV,
      NgaySinh = p_NgaySinh,
      LuongCanBan = p_LuongCanBan,
      NgayCong = p_NgayCong,
      PhuCap = p_PhuCap
  WHERE MaNV = p_MaNV;

  COMMIT;
  DBMS_OUTPUT.PUT_LINE('P2b: Cap nhat thanh cong!');
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    DBMS_OUTPUT.PUT_LINE('P2b Loi: ' || SQLERRM);
END;
/
SHOW ERRORS;

-- PHIẾU 2c: SP_LuongLN (tính lương và hiển thị)
CREATE OR REPLACE PROCEDURE SP_LuongLN
AS
BEGIN
  DBMS_OUTPUT.PUT_LINE('=== BANG LUONG ===');
  FOR r IN (
    SELECT MaNV, TenNV,
           (LuongCanBan * NgayCong + PhuCap) AS Luong
    FROM tblNhanVien
  ) LOOP
    DBMS_OUTPUT.PUT_LINE(r.MaNV || ' - ' || r.TenNV || ' - Luong: ' || r.Luong);
  END LOOP;
END;
/
SHOW ERRORS;

-- PHIẾU 3: sp_them_nhan_vien1 (OUT) phiên bản yêu cầu (MaNV trùng->0, MaCV thiếu->1, OK->2)
CREATE OR REPLACE PROCEDURE sp_them_nhan_vien1 (
  p_MaNV     IN tblNhanVien.MaNV%TYPE,
  p_MaCV     IN tblNhanVien.MaCV%TYPE,
  p_TenNV    IN tblNhanVien.TenNV%TYPE,
  p_NgaySinh IN tblNhanVien.NgaySinh%TYPE,
  p_LuongCB  IN tblNhanVien.LuongCanBan%TYPE,
  p_NgayCong IN tblNhanVien.NgayCong%TYPE,
  p_PhuCap   IN tblNhanVien.PhuCap%TYPE,
  p_KetQua   OUT NUMBER
)
AS
  v_dem_nv NUMBER := 0;
  v_dem_cv NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem_nv FROM tblNhanVien WHERE MaNV = p_MaNV;
  IF v_dem_nv > 0 THEN
    p_KetQua := 0;
    RETURN;
  END IF;

  SELECT COUNT(*) INTO v_dem_cv FROM tblChucVu WHERE MaCV = p_MaCV;
  IF v_dem_cv = 0 THEN
    p_KetQua := 1;
    RETURN;
  END IF;

  INSERT INTO tblNhanVien(MaNV, MaCV, TenNV, NgaySinh, LuongCanBan, NgayCong, PhuCap)
  VALUES (p_MaNV, p_MaCV, p_TenNV, p_NgaySinh, p_LuongCB, p_NgayCong, p_PhuCap);

  COMMIT;
  p_KetQua := 2;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_KetQua := -1;
END;
/
SHOW ERRORS;

-- PHIẾU 3: cập nhật NgaySinh (không thấy ->0, thấy ->1)
CREATE OR REPLACE PROCEDURE sp_capnhat_ngaysinh_nv (
  p_MaNV     IN  tblNhanVien.MaNV%TYPE,
  p_NgaySinh IN  tblNhanVien.NgaySinh%TYPE,
  p_KetQua   OUT NUMBER
)
AS
  v_dem NUMBER := 0;
BEGIN
  SELECT COUNT(*) INTO v_dem FROM tblNhanVien WHERE MaNV = p_MaNV;

  IF v_dem = 0 THEN
    p_KetQua := 0;
    RETURN;
  END IF;

  UPDATE tblNhanVien
  SET NgaySinh = p_NgaySinh
  WHERE MaNV = p_MaNV;

  COMMIT;
  p_KetQua := 1;
EXCEPTION
  WHEN OTHERS THEN
    ROLLBACK;
    p_KetQua := -1;
END;
/
SHOW ERRORS;

--------------------------------------------------------------------------------
-- TEST PHIẾU 2 + 3
--------------------------------------------------------------------------------
BEGIN
  SP_Them_Nhan_Vien('NV10','CVXX','Test',SYSDATE,1000,1,1); -- MaCV sai -> báo
  SP_Them_Nhan_Vien('NV10','CV03','Test',TO_DATE('10/10/2000','DD/MM/YYYY'),5000000,26,300000);
END;
/

BEGIN
  SP_CapNhat_Nhan_Vien('NV10','CV02','Test Update',TO_DATE('11/11/2001','DD/MM/YYYY'),6000000,24,400000);
END;
/

BEGIN
  SP_LuongLN;
END;
/

DECLARE v_kq NUMBER;
BEGIN
  sp_them_nhan_vien1('NV01','CV01','Trung MaNV',SYSDATE,1,1,1,v_kq);
  DBMS_OUTPUT.PUT_LINE('P3 them (trung MaNV) KQ='||v_kq); -- 0

  sp_them_nhan_vien1('NV99','CVXX','Sai MaCV',SYSDATE,1,1,1,v_kq);
  DBMS_OUTPUT.PUT_LINE('P3 them (sai MaCV) KQ='||v_kq); -- 1

  sp_them_nhan_vien1('NV98','CV03','OK',TO_DATE('01/01/2002','DD/MM/YYYY'),3000000,26,200000,v_kq);
  DBMS_OUTPUT.PUT_LINE('P3 them (OK) KQ='||v_kq); -- 2

  sp_capnhat_ngaysinh_nv('NV98', TO_DATE('05/05/2003','DD/MM/YYYY'), v_kq);
  DBMS_OUTPUT.PUT_LINE('P3 cap nhat ngaysinh KQ='||v_kq); -- 1
END;
/