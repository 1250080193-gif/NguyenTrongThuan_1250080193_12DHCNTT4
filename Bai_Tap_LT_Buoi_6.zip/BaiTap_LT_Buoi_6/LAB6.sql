-- xoa bang
begin
  execute immediate 'drop table taikhoanvay purge';
exception
  when others then null;
end;
/
begin
  execute immediate 'drop table taikhoangoi purge';
exception
  when others then null;
end;
/
begin
  execute immediate 'drop table chinhanh purge';
exception
  when others then null;
end;
/
begin
  execute immediate 'drop table khachhang purge';
exception
  when others then null;
end;
/
begin
  execute immediate 'drop table nganhang purge';
exception
  when others then null;
end;
/

-- tao bang
create table nganhang (
  manh number(2) primary key,
  tennh varchar2(100) not null
);

create table khachhang (
  makh varchar2(20) primary key,
  tenkh varchar2(100) not null,
  diachi varchar2(200)
);

create table chinhanh (
  macn varchar2(10) primary key,
  manh number(2) not null,
  thanhphocn varchar2(50) not null,
  taisan number(15) not null,
  constraint fk_chinhanh_nganhang
    foreign key (manh) references nganhang(manh)
);

create table taikhoangoi (
  sotkg varchar2(10) primary key,
  makh varchar2(20) not null,
  macn varchar2(10) not null,
  sotiengoi number(15) not null,
  constraint fk_tkg_khachhang foreign key (makh) references khachhang(makh),
  constraint fk_tkg_chinhanh foreign key (macn) references chinhanh(macn)
);

create table taikhoanvay (
  sotkv varchar2(10) primary key,
  makh varchar2(20) not null,
  macn varchar2(10) not null,
  sotienvay number(15) not null,
  constraint fk_tkv_khachhang foreign key (makh) references khachhang(makh),
  constraint fk_tkv_chinhanh foreign key (macn) references chinhanh(macn)
);

-- insert
insert into nganhang values (1, 'Ngan Hang Cong Thuong');
insert into nganhang values (2, 'Ngan Hang Ngoai Thuong');
insert into nganhang values (3, 'Ngan Hang Nong Nghiep');
insert into nganhang values (4, 'Ngan Hang A Chau');
insert into nganhang values (5, 'Ngan Hang Thuong Tin');

insert into chinhanh values ('CN01', 1, 'Da Lat', 2000000000);
insert into chinhanh values ('CN02', 2, 'Nha Trang', 2700000000);
insert into chinhanh values ('CN03', 3, 'Thanh Hoa', 4500000000);
insert into chinhanh values ('CN04', 4, 'TP HCM', 6000000000);
insert into chinhanh values ('CN05', 5, 'Da Nang', 7000000000);
insert into chinhanh values ('CN11', 1, 'TP HCM', 5000000000);
insert into chinhanh values ('CN12', 2, 'Hue', 1400000000);
insert into chinhanh values ('CN13', 3, 'Da Nang', 3600000000);
insert into chinhanh values ('CN14', 4, 'Ha Noi', 5700000000);
insert into chinhanh values ('CN21', 1, 'Ha Noi', 3500000000);
insert into chinhanh values ('CN22', 2, 'Ha Noi', 4500000000);
insert into chinhanh values ('CN23', 3, 'Da Lat', 2400000000);
insert into chinhanh values ('CN31', 1, 'Da Nang', 4000000000);
insert into chinhanh values ('CN32', 2, 'TP HCM', 5600000000);
insert into chinhanh values ('CN33', 3, 'Can Tho', 5400000000);
insert into chinhanh values ('CN43', 3, 'Nam Dinh', 3600000000);

insert into khachhang values ('111222333', 'Ho Thi Thanh Thao', '456 Le Duan, Ha Noi');
insert into khachhang values ('112233445', 'Tran Van Tien', '12 Dien Bien Phu, Q1, TP HCM');
insert into khachhang values ('123123123', 'Phan Thi Quynh Nhu', '54 Hai Ba Trung, Ha Noi');
insert into khachhang values ('123412341', 'Nguyen Van Thao', '34 Tran Phu, TP Nha Trang');
insert into khachhang values ('123456789', 'Nguyen Thi Hoa', '1/4 Hoang Van Thu, Da Lat');
insert into khachhang values ('221133445', 'Nguyen Thi Kim Mai', '4 Tran Binh Trong, Da Lat');
insert into khachhang values ('222111333', 'Do Tien Dong', '123 Tran Phu, Nam Dinh');
insert into khachhang values ('331122445', 'Bui Thi Dong', '345 Tran Hung Dao, Thanh Hoa');
insert into khachhang values ('333111222', 'Tran Dinh Hung', '783 Ly Thuong Kiet, Can Tho');
insert into khachhang values ('441122335', 'Nguyen dinh Cuong', 'P12 Thanh Xuan Nam, Q Thanh Xuan');
insert into khachhang values ('456456456', 'Tran Nam Son', '5 Le Duan, TP Da Nang');
insert into khachhang values ('551122334', 'Tran Thi Khanh Van', '1A Ho Tung Mau, Da Lat');
insert into khachhang values ('987654321', 'Ho Thanh Son', '209 Tran Hung Dao, Q5, TP HCM');

insert into taikhoangoi values ('00001A', '123123123', 'CN01', 10000000);
insert into taikhoangoi values ('00001C', '123456789', 'CN01', 127000000);
insert into taikhoangoi values ('00002A', '221133445', 'CN02', 12500000);
insert into taikhoangoi values ('00003H', '456456456', 'CN03', 123000000);
insert into taikhoangoi values ('00005A', '222111333', 'CN05', 1200000);
insert into taikhoangoi values ('00005D', '987654321', 'CN05', 345000000);
insert into taikhoangoi values ('00005N', '123412341', 'CN05', 45000000);
insert into taikhoangoi values ('00003A', '331122445', 'CN13', 27000000);
insert into taikhoangoi values ('00004D', '551122334', 'CN14', 560000000);
insert into taikhoangoi values ('00004P', '123456789', 'CN14', 35400000);
insert into taikhoangoi values ('00001B', '123412341', 'CN21', 67000000);
insert into taikhoangoi values ('00002G', '222111333', 'CN22', 56000000);
insert into taikhoangoi values ('00004F', '987654321', 'CN23', 4500000);
insert into taikhoangoi values ('00003D', '333111222', 'CN33', 47000000);

insert into taikhoanvay values ('10001A', '111222333', 'CN01', 10000000);
insert into taikhoanvay values ('10002A', '333111222', 'CN02', 6000000);
insert into taikhoanvay values ('10004A', '551122334', 'CN04', 20000000);
insert into taikhoanvay values ('10005G', '221133445', 'CN05', 15000000);
insert into taikhoanvay values ('10001D', '987654321', 'CN11', 45000000);
insert into taikhoanvay values ('10002D', '112233445', 'CN12', 12000000);
insert into taikhoanvay values ('10003F', '441122335', 'CN13', 5500000);
insert into taikhoanvay values ('10005A', '123123123', 'CN14', 12500000);

commit;

select count(*) from nganhang;
select count(*) from chinhanh;
select count(*) from khachhang;
select count(*) from taikhoangoi;
select count(*) from taikhoanvay;

-- 1. tim ten tat ca cac ngan hang co chi nhanh ngan hang o thanh pho "Da Lat".
select distinct nh.tennh
from nganhang nh
join chinhanh cn on cn.manh = nh.manh
where cn.thanhphocn = 'Da Lat';

-- 2. tim tat ca nhung thanh pho ma co chi nhanh cua ngan hang cong thuong.
select distinct cn.thanhphocn
from nganhang nh
join chinhanh cn on cn.manh = nh.manh
where nh.tennh = 'Ngan Hang Cong Thuong';

-- 3. tim thong tin ve tat ca cac chi nhanh cua ngan hang cong thuong co dia diem o "TP HCM".
select cn.macn, cn.manh, cn.thanhphocn, cn.taisan
from nganhang nh
join chinhanh cn on cn.manh = nh.manh
where nh.tennh = 'Ngan Hang Cong Thuong'
  and cn.thanhphocn = 'TP HCM';

-- 4. xuat thong tin tung ngan hang va chi nhanh cua no.
select nh.manh, nh.tennh, cn.macn, cn.thanhphocn, cn.taisan
from nganhang nh
left join chinhanh cn on cn.manh = nh.manh
order by nh.manh, cn.macn;

-- 5. tim khach hang ma dia chi cua ho o 'Ha Noi'.
select makh, tenkh, diachi
from khachhang
where diachi like '%Ha Noi%';

-- 6. tim cac khach hang co ten Son.
select makh, tenkh, diachi
from khachhang
where tenkh like '%Son%';

-- 7. tim cac khach hang ma dia chi cua ho o duong "Tran Hung Dao".
select makh, tenkh, diachi
from khachhang
where diachi like '%Tran Hung Dao%';

-- 8. tim cac khach hang co ten "Thao".
select makh, tenkh, diachi
from khachhang
where tenkh like '%Thao%';

-- 9. tim khach hang co ma so bat dau la '11' va o 'TP HCM'.
select makh, tenkh, diachi
from khachhang
where makh like '11%'
  and diachi like '%TP HCM%';

-- 10. xuat thong tin ve ten ngan hang, thanh pho chi nhanh va tai san theo thu tu tang
--     cua tai san chi nhanh, neu tai san trung nhau thi sap tang theo thanh pho chi nhanh.
select nh.tennh, cn.thanhphocn, cn.taisan
from nganhang nh
join chinhanh cn on cn.manh = nh.manh
order by cn.taisan asc, cn.thanhphocn asc;

-- 11. tim thong tin ngan hang va chi nhanh ngan hang ma 3000000000 < tai san < 5000000000.
select nh.manh, nh.tennh, cn.macn, cn.thanhphocn, cn.taisan
from nganhang nh
join chinhanh cn on cn.manh = nh.manh
where cn.taisan > 3000000000
  and cn.taisan < 5000000000;

-- 12. cho biet tai san trung binh chi nhanh cua tung ngan hang.
select nh.manh, nh.tennh, avg(cn.taisan) as taisan_trungbinh
from nganhang nh
join chinhanh cn on cn.manh = nh.manh
group by nh.manh, nh.tennh
order by nh.manh;

-- 13. tim thong tin khach hang co tai khoan vay tai ngan hang cong thuong va co ten la 'Thao'.
select distinct kh.makh, kh.tenkh, kh.diachi
from khachhang kh
join taikhoanvay tkv on tkv.makh = kh.makh
join chinhanh cn on cn.macn = tkv.macn
join nganhang nh on nh.manh = cn.manh
where nh.tennh = 'Ngan Hang Cong Thuong'
  and kh.tenkh like '%Thao%';

-- 14. xuat thong tin ve ten ngan hang va tong tai san cua cac ngan hang.
select nh.manh, nh.tennh, sum(cn.taisan) as tong_taisan
from nganhang nh
join chinhanh cn on cn.manh = nh.manh
group by nh.manh, nh.tennh
order by nh.manh;

-- 15. tim macn va taisan cua chi nhanh co tai san lon nhat.
select macn, taisan
from chinhanh
where taisan = (select max(taisan) from chinhanh);

-- 16. liet ke tat ca nhung khach hang co tai khoan goi tai chi nhanh ngan hang "A Chau".
select distinct kh.makh, kh.tenkh, kh.diachi
from khachhang kh
join taikhoangoi tkg on tkg.makh = kh.makh
join chinhanh cn on cn.macn = tkg.macn
join nganhang nh on nh.manh = cn.manh
where nh.tennh = 'Ngan Hang A Chau';

-- 17. tim tat ca cac so tai khoan vay thuc hien tai chi nhanh cua ngan hang ngoai thuong
--     ma so tien vay > 1200000.
select tkv.sotkv
from taikhoanvay tkv
join chinhanh cn on cn.macn = tkv.macn
join nganhang nh on nh.manh = cn.manh
where nh.tennh = 'Ngan Hang Ngoai Thuong'
  and tkv.sotienvay > 1200000;

-- 18. tinh tong so tien ma moi chi nhanh ngan hang dang duoc khach hang goi.
select cn.macn, cn.thanhphocn, sum(tkg.sotiengoi) as tong_tien_goi
from chinhanh cn
join taikhoangoi tkg on tkg.macn = cn.macn
group by cn.macn, cn.thanhphocn
order by cn.macn;

-- 19. xuat thong tin ve tai khoan vay va tai khoan goi hien co cua tat ca khach hang co ten 'Son'.
select kh.makh, kh.tenkh,
       tkv.sotkv, tkv.sotienvay,
       tkg.sotkg, tkg.sotiengoi
from khachhang kh
left join taikhoanvay tkv on tkv.makh = kh.makh
left join taikhoangoi tkg on tkg.makh = kh.makh
where kh.tenkh like '%Son%'
order by kh.makh, tkv.sotkv, tkg.sotkg;

-- 20. tim thong tin ve khach hang co tong so tien vay tai tat ca cac ngan hang > 30000000.
select kh.makh, kh.tenkh, sum(tkv.sotienvay) as tong_tien_vay
from khachhang kh
join taikhoanvay tkv on tkv.makh = kh.makh
group by kh.makh, kh.tenkh
having sum(tkv.sotienvay) > 30000000
order by tong_tien_vay desc;

