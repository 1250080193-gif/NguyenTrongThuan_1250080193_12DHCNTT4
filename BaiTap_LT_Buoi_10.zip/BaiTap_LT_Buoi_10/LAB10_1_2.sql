-- 1. INSERT NHAP
CREATE OR REPLACE TRIGGER trg_Nhap
BEFORE INSERT ON Nhap
FOR EACH ROW
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF v_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaSP khong ton tai');
    END IF;
    IF :NEW.SoLuongN <= 0 OR :NEW.DonGiaN <= 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'SoLuongN va DonGiaN phai > 0');
    END IF;
    UPDATE SanPham
    SET SoLuong = SoLuong + :NEW.SoLuongN
    WHERE MaSP = :NEW.MaSP;
END;

-- 2. INSERT XUAT
CREATE OR REPLACE TRIGGER trg_Xuat
BEFORE INSERT ON Xuat
FOR EACH ROW
DECLARE
    v_count NUMBER;
    v_soluong NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF v_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20001, 'MaSP khong ton tai');
    END IF;
    SELECT SoLuong INTO v_soluong
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;
    IF :NEW.SoLuongX > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20002, 'Khong du hang de xuat');
    END IF;
    UPDATE SanPham
    SET SoLuong = SoLuong - :NEW.SoLuongX
    WHERE MaSP = :NEW.MaSP;
END;

-- 3. DELETE XUAT
CREATE OR REPLACE TRIGGER trg_XoaXuat
AFTER DELETE ON Xuat
FOR EACH ROW
BEGIN
    UPDATE SanPham
    SET SoLuong = SoLuong + :OLD.SoLuongX
    WHERE MaSP = :OLD.MaSP;
END;

-- 4. UPDATE XUAT
CREATE OR REPLACE TRIGGER trg_CapNhatXuat
FOR UPDATE ON Xuat
COMPOUND TRIGGER

BEFORE STATEMENT IS
BEGIN
    pkg_state.g_count := 0;
END BEFORE STATEMENT;

BEFORE EACH ROW IS
    v_diff NUMBER;
    v_soluong NUMBER;
BEGIN
    pkg_state.g_count := pkg_state.g_count + 1;

    IF pkg_state.g_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Chi duoc update 1 dong');
    END IF;
    SELECT SoLuong INTO v_soluong
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;
    v_diff := :NEW.SoLuongX - :OLD.SoLuongX;

    IF v_diff > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20002, 'Khong du hang de cap nhat');
    END IF;
    UPDATE SanPham
    SET SoLuong = SoLuong - v_diff
    WHERE MaSP = :NEW.MaSP;
END BEFORE EACH ROW;
END;


-- 5. UPDATE NHAP
CREATE OR REPLACE TRIGGER trg_CapNhatNhap
FOR UPDATE ON Nhap
COMPOUND TRIGGER

BEFORE STATEMENT IS
BEGIN
    pkg_state.g_count := 0;
END BEFORE STATEMENT;

BEFORE EACH ROW IS
    v_diff NUMBER;
    v_count NUMBER;
BEGIN
    pkg_state.g_count := pkg_state.g_count + 1;

    IF pkg_state.g_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20001, 'Chi duoc update 1 dong');
    END IF;
    SELECT COUNT(*) INTO v_count
    FROM SanPham
    WHERE MaSP = :NEW.MaSP;

    IF v_count = 0 THEN
        RAISE_APPLICATION_ERROR(-20002, 'MaSP khong ton tai');
    END IF;

    v_diff := :NEW.SoLuongN - :OLD.SoLuongN;

    UPDATE SanPham
    SET SoLuong = SoLuong + v_diff
    WHERE MaSP = :NEW.MaSP;
END BEFORE EACH ROW;
END;


-- 6. DELETE NHAP
CREATE OR REPLACE TRIGGER trg_XoaNhap
AFTER DELETE ON Nhap
FOR EACH ROW
BEGIN
    UPDATE SanPham
    SET SoLuong = SoLuong - :OLD.SoLuongN
    WHERE MaSP = :OLD.MaSP;
END;
