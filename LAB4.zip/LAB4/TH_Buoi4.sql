SET SERVEROUTPUT ON;

DROP TABLE GRADE CASCADE CONSTRAINTS;
DROP TABLE ENROLLMENT CASCADE CONSTRAINTS;
DROP TABLE CLASS CASCADE CONSTRAINTS;
DROP TABLE STUDENT CASCADE CONSTRAINTS;
DROP TABLE INSTRUCTOR CASCADE CONSTRAINTS;
DROP TABLE COURSE CASCADE CONSTRAINTS;

-- COURSE
CREATE TABLE COURSE (
    CourseNo NUMBER(8,0) PRIMARY KEY,
    Description VARCHAR2(50),
    Cost NUMBER(9,2),
    Prerequisite NUMBER(8,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);

-- INSTRUCTOR
CREATE TABLE INSTRUCTOR (
    InstructorID NUMBER(8) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25),
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);

-- STUDENT
CREATE TABLE STUDENT (
    StudentID NUMBER(8,0) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25) NOT NULL,
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    Employer VARCHAR2(50),
    RegistrationDate DATE NOT NULL,
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);

-- CLASS
CREATE TABLE CLASS (
    ClassID NUMBER(8,0) PRIMARY KEY,
    CourseNo NUMBER(8,0) NOT NULL,
    ClassNo NUMBER(3) NOT NULL,
    StartDateTime DATE,
    Location VARCHAR2(50),
    InstructorID NUMBER(8,0) NOT NULL,
    Capacity NUMBER(3,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,

    CONSTRAINT FK_CLASS_COURSE FOREIGN KEY (CourseNo) REFERENCES COURSE(CourseNo),
    CONSTRAINT FK_CLASS_INSTRUCTOR FOREIGN KEY (InstructorID) REFERENCES INSTRUCTOR(InstructorID)
);

-- ENROLLMENT
CREATE TABLE ENROLLMENT (
    StudentID NUMBER(8,0),
    ClassID NUMBER(8,0),
    EnrollDate DATE NOT NULL,
    FinalGrade NUMBER(3,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,

    CONSTRAINT PK_ENROLLMENT PRIMARY KEY (StudentID, ClassID),
    CONSTRAINT FK_ENR_STUDENT FOREIGN KEY (StudentID) REFERENCES STUDENT(StudentID),
    CONSTRAINT FK_ENR_CLASS FOREIGN KEY (ClassID) REFERENCES CLASS(ClassID)
);

--GRADE
CREATE TABLE GRADE (
    StudentID NUMBER(8),
    ClassID NUMBER(8),
    Grade NUMBER(3),
    Comments VARCHAR2(2000),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,

    CONSTRAINT PK_GRADE PRIMARY KEY (StudentID, ClassID),
    CONSTRAINT FK_GRADE_STUDENT FOREIGN KEY (StudentID) REFERENCES STUDENT(StudentID),
    CONSTRAINT FK_GRADE_CLASS FOREIGN KEY (ClassID) REFERENCES CLASS(ClassID)
);

-- COURSE
INSERT INTO COURSE VALUES (10, 'Database', 1000, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (20, 'Programming', 1200, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (30, 'AI', 1500, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (40, 'Web', 1300, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (50, 'Data Mining', 1400, NULL, USER, SYSDATE, USER, SYSDATE);

-- INSTRUCTOR
INSERT INTO INSTRUCTOR VALUES (1,'Mr','Nguyen','A','HCM','0123',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (2,'Mr','Tran','B','HCM','0456',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (3,'Mr','Le','C','HCM','0777',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (4,'Ms','Vo','D','HCM','0888',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (5,'Mr','Pham','E','HCM','0999',USER,SYSDATE,USER,SYSDATE);

-- STUDENT
INSERT INTO STUDENT VALUES (101,'Mr','Le','An','HCM','111',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (102,'Mr','Pham','Binh','HCM','222',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (103,'Mr','Nguyen','Cuong','HCM','333',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (104,'Ms','Tran','Dung','HCM','444',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (105,'Mr','Le','Huy','HCM','555',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (106,'Ms','Pham','Lan','HCM','666',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (107,'Mr','Hoang','Minh','HCM','777',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (108,'Ms','Do','Nga','HCM','888',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);

-- CLASS
INSERT INTO CLASS VALUES (1,10,1,SYSDATE,'A1',1,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (2,10,2,SYSDATE,'A2',1,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (3,20,1,SYSDATE,'B1',2,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (4,20,2,SYSDATE,'B2',2,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (5,30,1,SYSDATE,'C1',3,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (6,30,2,SYSDATE,'C2',3,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (7,40,1,SYSDATE,'D1',4,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (8,50,1,SYSDATE,'E1',5,30,USER,SYSDATE,USER,SYSDATE);

-- ENROLLMENT 
INSERT INTO ENROLLMENT VALUES (101,1,SYSDATE,85,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (101,2,SYSDATE,90,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (101,3,SYSDATE,88,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (102,1,SYSDATE,70,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (102,2,SYSDATE,75,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (103,3,SYSDATE,60,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (104,4,SYSDATE,95,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (105,5,SYSDATE,80,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (106,6,SYSDATE,50,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (107,7,SYSDATE,40,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (108,8,SYSDATE,65,USER,SYSDATE,USER,SYSDATE);

-- GRADE
INSERT INTO GRADE VALUES (101,1,85,'Tot',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (102,2,70,'On dinh',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (103,3,60,'Can co gang',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (104,4,95,'Excellent',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (105,5,80,'Good',USER,SYSDATE,USER,SYSDATE);

COMMIT;

--VIEW

-- Câu 1.1: Tạo view vw_course_summary - thông tin tổng quan môn học
CREATE OR REPLACE VIEW vw_course_summary AS
SELECT  co.courseno,
        co.description,
        co.cost,
        COUNT(DISTINCT cl.classid) AS so_lop,
        COUNT(e.studentid)        AS tong_sv
FROM    course co
LEFT JOIN class cl
        ON co.courseno = cl.courseno
LEFT JOIN enrollment e
        ON cl.classid = e.classid
GROUP BY co.courseno,
         co.description,
         co.cost
ORDER BY tong_sv DESC;

-- Kiem tra view:
SELECT *
FROM   vw_course_summary;

--Câu 1.2: Tạo view vw_student_status - thông tin sinh viên và tình trạng học tập
CREATE OR REPLACE VIEW vw_student_status AS
SELECT  s.studentid,
        s.firstname || ' ' || s.lastname AS ho_ten,
        COUNT(e.classid)                AS so_lop_hoc,
        NVL(SUM(co.cost), 0)            AS tong_hoc_phi,
        ROUND(AVG(e.finalgrade), 2)     AS diem_tb
FROM    student s
JOIN    enrollment e
        ON s.studentid = e.studentid
JOIN    class cl
        ON e.classid = cl.classid
JOIN    course co
        ON cl.courseno = co.courseno
GROUP BY s.studentid,
         s.firstname,
         s.lastname
HAVING  COUNT(e.classid) >= 1
ORDER BY s.studentid;

SELECT *
FROM   vw_student_status;

--Câu 1.3: Tạo view vw_class_availability - lớp học còn chỗ trống
CREATE OR REPLACE VIEW vw_class_availability AS
SELECT  cl.classid,
        cl.courseno,
        co.description,
        i.firstname || ' ' || i.lastname AS ten_giao_vien,
        cl.capacity,
        COUNT(e.studentid)              AS so_da_dk,
        cl.capacity - COUNT(e.studentid) AS cho_trong,
        CASE
            WHEN cl.capacity - COUNT(e.studentid) > 0 THEN 'Con cho'
            ELSE 'Het cho'
        END AS trang_thai
FROM    class cl
JOIN    course co
        ON cl.courseno = co.courseno
JOIN    instructor i
        ON cl.instructorid = i.instructorid
LEFT JOIN enrollment e
        ON cl.classid = e.classid
GROUP BY cl.classid,
         cl.courseno,
         co.description,
         i.firstname,
         i.lastname,
         cl.capacity
HAVING  cl.capacity - COUNT(e.studentid) > 0
ORDER BY cl.classid;

SELECT *
FROM   vw_class_availability;

--Câu 1.4: Tạo view vw_top_courses - chỉ đọc, top 5 môn được đăng ký nhiều nhất
CREATE OR REPLACE VIEW vw_top_courses AS
SELECT  courseno,
        description,
        cost,
        tong_dk,
        hang
FROM   (
        SELECT  co.courseno,
                co.description,
                co.cost,
                COUNT(e.studentid) AS tong_dk,
                RANK() OVER (ORDER BY COUNT(e.studentid) DESC) AS hang
        FROM    course co
        LEFT JOIN class cl
                ON co.courseno = cl.courseno
        LEFT JOIN enrollment e
                ON cl.classid = e.classid
        GROUP BY co.courseno,
                 co.description,
                 co.cost
       )
WHERE  hang <= 5
ORDER BY hang
WITH READ ONLY;

SELECT *
FROM   vw_top_courses;

-- Thu INSERT vao view nay (se bao loi ORA-42399):
INSERT INTO vw_top_courses (courseno, description, cost)
VALUES (999, 'Test', 100);

-- Oracle bao: ORA-42399: cannot perform a DML operation on a read-only view

--Câu 1.5: Tạo view vw_pending_enrollment với WITH CHECK OPTION và kiểm tra
CREATE OR REPLACE VIEW vw_pending_enrollment AS
SELECT  studentid,
        classid,
        enrolldate,
        finalgrade,
        createdby,
        createddate,
        modifiedby,
        modifieddate
FROM    enrollment
WHERE   finalgrade IS NULL
WITH CHECK OPTION;

SELECT *
FROM   vw_pending_enrollment;

-- INSERT 1: FinalGrade = NULL -> THANH CONG (thoa dieu kien WHERE)
INSERT INTO vw_pending_enrollment
        (studentid,
         classid,
         enrolldate,
         createdby,
         createddate,
         modifiedby,
         modifieddate)
VALUES  (999,
         1,
         SYSDATE,
         USER,
         SYSDATE,
         USER,
         SYSDATE);

-- INSERT 2: FinalGrade = 85 -> LOI ORA-01402 (vi pham WITH CHECK OPTION)
INSERT INTO vw_pending_enrollment
        (studentid,
         classid,
         enrolldate,
         finalgrade,
         createdby,
         createddate,
         modifiedby,
         modifieddate)
VALUES  (998,
         1,
         SYSDATE,
         85,
         USER,
         SYSDATE,
         USER,
         SYSDATE);

-- ORA-01402: view WITH CHECK OPTION where-clause violation

-- STORED PROCEDURE

--Câu 2.1: Thủ tục enroll_student - đăng ký sinh viên vào lớp học
CREATE OR REPLACE PROCEDURE enroll_student
(
    p_studentid IN NUMBER,
    p_classid   IN NUMBER
)
IS
    v_check     NUMBER;
    v_capacity  NUMBER;
    v_enrolled  NUMBER;
BEGIN
    -- DK1: Sinh vien phai ton tai
    SELECT COUNT(*)
    INTO   v_check
    FROM   student
    WHERE  studentid = p_studentid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien ' || p_studentid || ' khong ton tai!');
        RETURN;
    END IF;

    -- DK2: Lop hoc phai ton tai
    SELECT COUNT(*)
    INTO   v_check
    FROM   class
    WHERE  classid = p_classid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop hoc ' || p_classid || ' khong ton tai!');
        RETURN;
    END IF;

    -- DK3: Kiem tra con cho trong
    SELECT capacity
    INTO   v_capacity
    FROM   class
    WHERE  classid = p_classid;

    SELECT COUNT(*)
    INTO   v_enrolled
    FROM   enrollment
    WHERE  classid = p_classid;

    IF v_enrolled >= v_capacity THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop ' || p_classid || ' da day! ('
                             || v_enrolled || '/' || v_capacity || ')');
        RETURN;
    END IF;

    -- DK4: Sinh vien chua dang ky lop nay
    SELECT COUNT(*)
    INTO   v_check
    FROM   enrollment
    WHERE  studentid = p_studentid
    AND    classid   = p_classid;

    IF v_check > 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky lop nay roi!');
        RETURN;
    END IF;

    -- DK5: Sinh vien chua qua 3 lop
    SELECT COUNT(*)
    INTO   v_check
    FROM   enrollment
    WHERE  studentid = p_studentid;

    IF v_check >= 3 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da dang ky du 3 lop!');
        RETURN;
    END IF;

    -- Tat ca OK: INSERT
    INSERT INTO enrollment
            (studentid,
             classid,
             enrolldate,
             createdby,
             createddate,
             modifiedby,
             modifieddate)
    VALUES  (p_studentid,
             p_classid,
             SYSDATE,
             USER,
             SYSDATE,
             USER,
             SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Dang ky thanh cong! SV '
                         || p_studentid || ' -> Lop ' || p_classid);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI HE THONG] ' || SQLERRM);
END enroll_student;
/

-- Kiem tra:
BEGIN
    enroll_student(101, 5);   -- Hop le
    enroll_student(999, 5);   -- SV khong ton tai
    enroll_student(101, 999); -- Lop khong ton tai
END;
/

--Câu 2.2: Thủ tục update_final_grade - cập nhật điểm tổng kết
CREATE OR REPLACE PROCEDURE update_final_grade
(
    p_studentid IN NUMBER,
    p_classid   IN NUMBER,
    p_grade     IN NUMBER
)
IS
    v_check      NUMBER;
    v_old_grade  NUMBER;
BEGIN
    -- Kiem tra diem hop le
    IF p_grade < 0 OR p_grade > 100 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Diem khong hop le! Phai tu 0 den 100.');
        RETURN;
    END IF;

    -- Kiem tra cap (StudentID, ClassID) ton tai trong ENROLLMENT
    SELECT COUNT(*)
    INTO   v_check
    FROM   enrollment
    WHERE  studentid = p_studentid
    AND    classid   = p_classid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien chua dang ky lop nay!');
        RETURN;
    END IF;

    -- Luu diem cu
    SELECT finalgrade
    INTO   v_old_grade
    FROM   enrollment
    WHERE  studentid = p_studentid
    AND    classid   = p_classid;

    -- Cap nhat ENROLLMENT
    UPDATE enrollment
    SET    finalgrade  = p_grade,
           modifiedby  = USER,
           modifieddate = SYSDATE
    WHERE  studentid   = p_studentid
    AND    classid     = p_classid;

    -- Dong bo sang bang GRADE bang MERGE INTO
    MERGE INTO grade g
    USING (SELECT p_studentid AS sid,
                  p_classid   AS cid
           FROM   dual) src
    ON (g.studentid = src.sid AND g.classid = src.cid)

    WHEN MATCHED THEN
        UPDATE SET g.grade        = p_grade,
                   g.modifiedby   = USER,
                   g.modifieddate = SYSDATE

    WHEN NOT MATCHED THEN
        INSERT (studentid,
                classid,
                grade,
                createdby,
                createddate,
                modifiedby,
                modifieddate)
        VALUES (p_studentid,
                p_classid,
                p_grade,
                USER,
                SYSDATE,
                USER,
                SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Da cap nhat diem SV ' || p_studentid
                         || ' lop ' || p_classid
                         || ': Cu=' || NVL(TO_CHAR(v_old_grade), 'NULL')
                         || ' -> Moi=' || p_grade);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
END update_final_grade;
/

--Câu 2.3: Thủ tục transfer_student - chuyển lớp cho sinh viên
CREATE OR REPLACE PROCEDURE transfer_student
(
    p_studentid    IN NUMBER,
    p_old_classid  IN NUMBER,
    p_new_classid  IN NUMBER
)
IS
    v_check     NUMBER;
    v_capacity  NUMBER;
    v_enrolled  NUMBER;
BEGIN
    -- DK1: Sinh vien dang hoc o lop cu
    SELECT COUNT(*)
    INTO   v_check
    FROM   enrollment
    WHERE  studentid = p_studentid
    AND    classid   = p_old_classid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien khong dang hoc lop ' || p_old_classid);
        RETURN;
    END IF;

    -- DK2: Lop moi con cho trong
    SELECT capacity
    INTO   v_capacity
    FROM   class
    WHERE  classid = p_new_classid;

    SELECT COUNT(*)
    INTO   v_enrolled
    FROM   enrollment
    WHERE  classid = p_new_classid;

    IF v_enrolled >= v_capacity THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Lop moi ' || p_new_classid || ' da day!');
        RETURN;
    END IF;

    -- DK3: Sinh vien chua dang ky lop moi
    SELECT COUNT(*)
    INTO   v_check
    FROM   enrollment
    WHERE  studentid = p_studentid
    AND    classid   = p_new_classid;

    IF v_check > 0 THEN
        DBMS_OUTPUT.PUT_LINE('[LOI] Sinh vien da o trong lop moi roi!');
        RETURN;
    END IF;

    -- Tat ca OK: thuc hien chuyen lop
    SAVEPOINT sp_truoc_chuyen;

    -- Buoc 1: Xoa khoi lop cu
    DELETE FROM enrollment
    WHERE  studentid = p_studentid
    AND    classid   = p_old_classid;

    SAVEPOINT sp_sau_xoa;

    -- Buoc 2: Them vao lop moi
    INSERT INTO enrollment
            (studentid,
             classid,
             enrolldate,
             createdby,
             createddate,
             modifiedby,
             modifieddate)
    VALUES  (p_studentid,
             p_new_classid,
             SYSDATE,
             USER,
             SYSDATE,
             USER,
             SYSDATE);

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Da chuyen SV ' || p_studentid
                         || ' tu lop ' || p_old_classid
                         || ' sang lop ' || p_new_classid);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK TO sp_truoc_chuyen;
        DBMS_OUTPUT.PUT_LINE('[LOI] Chuyen lop that bai: ' || SQLERRM);
        DBMS_OUTPUT.PUT_LINE('Da rollback ve trang thai ban dau.');
END transfer_student;
/

--Câu 2.4: Thủ tục report_class_detail — in báo cáo chi tiết lớp học
CREATE OR REPLACE PROCEDURE report_class_detail
(
    p_classid IN NUMBER
)
IS
    v_check      NUMBER;
    v_course     VARCHAR2(50);
    v_courseno   NUMBER;
    v_gv         VARCHAR2(50);
    v_loc        VARCHAR2(50);
    v_cap        NUMBER;
    v_stt        NUMBER := 0;
    v_tong       NUMBER := 0;
    v_sum_d      NUMBER := 0;
    v_co_d       NUMBER := 0;
    v_grade_txt  VARCHAR2(15);
BEGIN
    -- Kiem tra lop ton tai
    SELECT COUNT(*)
    INTO   v_check
    FROM   class
    WHERE  classid = p_classid;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Lop hoc ' || p_classid || ' khong ton tai!');
        RETURN;
    END IF;

    -- Lay thong tin lop
    SELECT  co.description,
            co.courseno,
            i.firstname || ' ' || i.lastname,
            cl.location,
            cl.capacity
    INTO    v_course,
            v_courseno,
            v_gv,
            v_loc,
            v_cap
    FROM    class cl
    JOIN    course co
            ON cl.courseno = co.courseno
    JOIN    instructor i
            ON cl.instructorid = i.instructorid
    WHERE   cl.classid = p_classid;

    -- In header bao cao
    DBMS_OUTPUT.PUT_LINE('=== BAO CAO LOP HOC: ' || p_classid || ' ===');
    DBMS_OUTPUT.PUT_LINE('Mon hoc : ' || v_courseno || ' - ' || v_course);
    DBMS_OUTPUT.PUT_LINE('Giao vien: ' || v_gv);
    DBMS_OUTPUT.PUT_LINE('Phong hoc: ' || NVL(v_loc, 'Chua xep phong'));
    DBMS_OUTPUT.PUT_LINE('Suc chua : ' || v_cap || ' cho');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 50, '-'));

    DBMS_OUTPUT.PUT_LINE('DANH SACH SINH VIEN:');
    DBMS_OUTPUT.PUT_LINE(RPAD('STT', 4) || ' | '
                         || RPAD('Ho Ten', 20) || ' | '
                         || LPAD('Diem TK', 8) || ' | Xep loai');
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 50, '-'));

    -- Duyet danh sach sinh vien
    FOR rec IN (
        SELECT  s.firstname || ' ' || s.lastname AS ho_ten,
                e.finalgrade
        FROM    enrollment e
        JOIN    student s
                ON e.studentid = s.studentid
        WHERE   e.classid = p_classid
        ORDER BY s.lastname, s.firstname
    )
    LOOP
        v_stt  := v_stt + 1;
        v_tong := v_tong + 1;

        -- Xep loai
        IF rec.finalgrade IS NULL THEN
            v_grade_txt := 'Chua co diem';

        ELSIF rec.finalgrade >= 90 THEN
            v_grade_txt := 'A';
            v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;

        ELSIF rec.finalgrade >= 80 THEN
            v_grade_txt := 'B';
            v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;

        ELSIF rec.finalgrade >= 70 THEN
            v_grade_txt := 'C';
            v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;

        ELSIF rec.finalgrade >= 50 THEN
            v_grade_txt := 'D';
            v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;

        ELSE
            v_grade_txt := 'F';
            v_sum_d := v_sum_d + rec.finalgrade; v_co_d := v_co_d + 1;
        END IF;

        DBMS_OUTPUT.PUT_LINE(
            LPAD(v_stt, 3) || ' | '
            || RPAD(rec.ho_ten, 20) || ' | '
            || LPAD(NVL(TO_CHAR(rec.finalgrade), 'NULL'), 7) || ' | '
            || v_grade_txt
        );
    END LOOP;

    -- In footer bao cao
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 50, '-'));
    DBMS_OUTPUT.PUT_LINE('Tong so sinh vien : ' || v_tong);

    IF v_co_d > 0 THEN
        DBMS_OUTPUT.PUT_LINE('Diem trung binh lop: '
                             || ROUND(v_sum_d / v_co_d, 2));
    ELSE
        DBMS_OUTPUT.PUT_LINE('Diem trung binh lop: Chua co diem');
    END IF;
END report_class_detail;
/

-- Goi thu tuc:
BEGIN
    report_class_detail(1);
END;
/

--Câu 2.5: Thủ tục sync_grade_from_enrollment - đồng bộ điểm từ ENROLLMENT sang GRADE
CREATE OR REPLACE PROCEDURE sync_grade_from_enrollment
IS
    v_check       NUMBER;
    v_dem_insert  NUMBER := 0;
    v_dem_update  NUMBER := 0;
BEGIN
    FOR rec IN (
        SELECT  studentid,
                classid,
                finalgrade
        FROM    enrollment
        WHERE   finalgrade IS NOT NULL
    )
    LOOP
        -- Kiem tra trong GRADE da co chua
        SELECT COUNT(*)
        INTO   v_check
        FROM   grade
        WHERE  studentid = rec.studentid
        AND    classid   = rec.classid;

        IF v_check = 0 THEN
            -- Chua co -> INSERT moi
            INSERT INTO grade
                    (studentid,
                     classid,
                     grade,
                     createdby,
                     createddate,
                     modifiedby,
                     modifieddate)
            VALUES  (rec.studentid,
                     rec.classid,
                     rec.finalgrade,
                     USER,
                     SYSDATE,
                     USER,
                     SYSDATE);

            v_dem_insert := v_dem_insert + 1;

        ELSE
            -- Da co -> UPDATE
            UPDATE grade
            SET    grade        = rec.finalgrade,
                   modifiedby   = USER,
                   modifieddate = SYSDATE
            WHERE  studentid    = rec.studentid
            AND    classid      = rec.classid;

            v_dem_update := v_dem_update + 1;
        END IF;
    END LOOP;

    COMMIT;

    DBMS_OUTPUT.PUT_LINE('[OK] Dong bo hoan tat!');
    DBMS_OUTPUT.PUT_LINE(' So ban ghi INSERT moi : ' || v_dem_insert);
    DBMS_OUTPUT.PUT_LINE(' So ban ghi UPDATE : ' || v_dem_update);

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        DBMS_OUTPUT.PUT_LINE('[LOI] ' || SQLERRM);
END sync_grade_from_enrollment;
/

BEGIN
    sync_grade_from_enrollment;
END;
/

-- TRIGGER

--Câu 3.1: Trigger trg_check_capacity - kiểm tra sức chứa khi đăng ký
CREATE OR REPLACE TRIGGER trg_check_capacity
BEFORE INSERT ON enrollment
FOR EACH ROW
DECLARE
    v_capacity  NUMBER;
    v_enrolled  NUMBER;
BEGIN
    -- Lay suc chua lop hoc
    SELECT capacity
    INTO   v_capacity
    FROM   class
    WHERE  classid = :NEW.classid;

    -- Dem so SV hien da dang ky
    SELECT COUNT(*)
    INTO   v_enrolled
    FROM   enrollment
    WHERE  classid = :NEW.classid;

    -- Tu choi neu lop da day
    IF v_enrolled >= v_capacity THEN
        RAISE_APPLICATION_ERROR(
            -20010,
            'LOI: Lop ' || :NEW.classid || ' da day! ('
            || v_enrolled || '/' || v_capacity || ' cho)'
        );
    END IF;
END trg_check_capacity;
/

-- Kiem tra trigger (dang ky vao lop da day):
INSERT INTO enrollment
        (studentid,
         classid,
         enrolldate,
         createdby,
         createddate,
         modifiedby,
         modifieddate)
VALUES  (103,
         1,
         SYSDATE,
         USER,
         SYSDATE,
         USER,
         SYSDATE);
         
--Câu 3.2: Trigger trg_grade_audit_log - ghi nhật ký thay đổi điểm
CREATE TABLE grade_audit_log (
    log_id     NUMBER GENERATED ALWAYS AS IDENTITY,
    studentid  NUMBER(8),
    classid    NUMBER(8),
    grade_cu   NUMBER(3),
    grade_moi  NUMBER(3),
    nguoi_sua  VARCHAR2(30),
    thoi_gian  DATE
);
/

CREATE OR REPLACE TRIGGER trg_grade_audit_log
AFTER UPDATE OF finalgrade ON enrollment
FOR EACH ROW
BEGIN
    -- Chi ghi log khi diem THUC SU thay doi
    IF ( :OLD.finalgrade IS NULL AND :NEW.finalgrade IS NOT NULL )
    OR ( :OLD.finalgrade IS NOT NULL AND :NEW.finalgrade IS NULL )
    OR ( :OLD.finalgrade != :NEW.finalgrade )
    THEN
        INSERT INTO grade_audit_log
                (studentid,
                 classid,
                 grade_cu,
                 grade_moi,
                 nguoi_sua,
                 thoi_gian)
        VALUES  ( :OLD.studentid,
                  :OLD.classid,
                  :OLD.finalgrade,
                  :NEW.finalgrade,
                  USER,
                  SYSDATE );
    END IF;
END trg_grade_audit_log;
/

-- Kiem tra trigger:
UPDATE enrollment
SET    finalgrade = 85
WHERE  studentid = 101
AND    classid   = 1;

COMMIT;

SELECT *
FROM   grade_audit_log;

--Câu 3.3: Trigger trg_prevent_course_delete - ngăn xóa môn học đang có lớp
CREATE OR REPLACE TRIGGER trg_prevent_course_delete
BEFORE DELETE ON course
FOR EACH ROW
DECLARE
    v_so_lop  NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO   v_so_lop
    FROM   class
    WHERE  courseno = :OLD.courseno;

    IF v_so_lop > 0 THEN
        RAISE_APPLICATION_ERROR(
            -20020,
            'Khong the xoa mon hoc ' || :OLD.courseno ||
            ' (' || :OLD.description || ') ' ||
            'vi con ' || v_so_lop || ' lop hoc dang ton tai!'
        );
    END IF;
    -- Neu v_so_lop = 0: trigger ket thuc binh thuong, Oracle tien hanh xoa
END trg_prevent_course_delete;
/

-- Kiem tra: xoa mon co lop (se bao loi)
DELETE FROM course
WHERE  courseno = 10;

-- Kiem tra: xoa mon khong co lop (thanh cong)
DELETE FROM course
WHERE  courseno = 999; -- Mon khong co lop nao

ROLLBACK;

SET SERVEROUTPUT ON;

-- ======================
-- TRIGGER: CHAN XOA COURSE NEU CON CLASS
-- ======================
CREATE OR REPLACE TRIGGER trg_prevent_course_delete
BEFORE DELETE ON course
FOR EACH ROW
DECLARE
    v_so_lop  NUMBER;
BEGIN
    -- Dem so lop cua mon hoc
    SELECT COUNT(*)
    INTO   v_so_lop
    FROM   class
    WHERE  courseno = :OLD.courseno;

    -- Neu con lop -> chan xoa
    IF v_so_lop > 0 THEN
        RAISE_APPLICATION_ERROR(
            -20020,
            'Khong the xoa mon hoc ' || :OLD.courseno ||
            ' (' || :OLD.description || ') ' ||
            'vi con ' || v_so_lop || ' lop hoc dang ton tai!'
        );
    END IF;
END trg_prevent_course_delete;
/

-- ======================
-- TEST 1: KHONG CO LOP (PHAI XOA DUOC)
-- ======================
-- Tao mon khong co lop
INSERT INTO course (courseno, description)
VALUES (888, 'Test Course');

COMMIT;

-- Xoa (thanh cong)
DELETE FROM course
WHERE courseno = 888;

-- Kiem tra
SELECT * FROM course WHERE courseno = 888;

ROLLBACK;

-- ======================
-- TEST 2: CO LOP (BI CHAN)
-- ======================
-- Tao mon
INSERT INTO course (courseno, description)
VALUES (889, 'Course Co Lop');

-- Tao class lien quan
INSERT INTO class (classid, courseno)
VALUES (9001, 889);

COMMIT;

-- Thu xoa (bi chan)
DELETE FROM course
WHERE courseno = 889;

ROLLBACK;

--Câu 3.4: Trigger trg_update_grade_summary - cập nhật bảng thống kê tự động
CREATE OR REPLACE TRIGGER trg_update_grade_summary
AFTER INSERT OR UPDATE OR DELETE ON enrollment
DECLARE
BEGIN
    MERGE INTO class_grade_summary cgs
    USING (
        SELECT classid,
               COUNT(finalgrade) AS so_sv,
               ROUND(AVG(finalgrade), 2) AS diem_tb,
               MAX(finalgrade) AS diem_cao_nhat,
               MIN(finalgrade) AS diem_thap_nhat
        FROM enrollment
        WHERE finalgrade IS NOT NULL
        GROUP BY classid
    ) src
    ON (cgs.classid = src.classid)

    WHEN MATCHED THEN
        UPDATE SET
            so_sv          = src.so_sv,
            diem_tb        = src.diem_tb,
            diem_cao_nhat  = src.diem_cao_nhat,
            diem_thap_nhat = src.diem_thap_nhat,
            cap_nhat_luc   = SYSDATE

    WHEN NOT MATCHED THEN
        INSERT (classid,
                so_sv,
                diem_tb,
                diem_cao_nhat,
                diem_thap_nhat,
                cap_nhat_luc)
        VALUES (src.classid,
                src.so_sv,
                src.diem_tb,
                src.diem_cao_nhat,
                src.diem_thap_nhat,
                SYSDATE);
END;
/
UPDATE enrollment
SET finalgrade = 95
WHERE studentid = 101 AND classid = 1;

COMMIT;

SELECT * FROM class_grade_summary
ORDER BY classid;

-- TỔNG HỢP

--Câu 4.1: Hệ thống báo cáo hoàn chỉnh - View + Procedure + Cursor
--Bước 1: Tạo view vw_instructor_workload:
CREATE OR REPLACE VIEW vw_instructor_workload AS
SELECT  i.instructorid,
        i.firstname || ' ' || i.lastname AS ho_ten,
        COUNT(DISTINCT cl.classid)      AS so_lop,
        COUNT(e.studentid)              AS tong_sv,
        ROUND(AVG(e.finalgrade), 2)     AS diem_tb_chung,
        CASE
            WHEN COUNT(DISTINCT cl.classid) >= 3 THEN 'Ban nhieu'
            WHEN COUNT(DISTINCT cl.classid) = 2  THEN 'Binh thuong'
            ELSE 'Nhe nhang'
        END AS muc_ban
FROM    instructor i
LEFT JOIN class cl
        ON i.instructorid = cl.instructorid
LEFT JOIN enrollment e
        ON cl.classid = e.classid
GROUP BY i.instructorid,
         i.firstname,
         i.lastname
ORDER BY so_lop DESC;

SELECT *
FROM   vw_instructor_workload;

--Bước 2: Thủ tục print_system_report:
CREATE OR REPLACE PROCEDURE print_system_report
IS
    v_so_mon  NUMBER;
    v_so_lop  NUMBER;
    v_so_sv   NUMBER;
    v_so_gv   NUMBER;
BEGIN
    -- Lay so lieu tong the
    SELECT COUNT(*) INTO v_so_mon FROM course;
    SELECT COUNT(*) INTO v_so_lop FROM class;
    SELECT COUNT(*) INTO v_so_sv  FROM student;
    SELECT COUNT(*) INTO v_so_gv  FROM instructor;

    -- In header
    DBMS_OUTPUT.PUT_LINE('==========================================');
    DBMS_OUTPUT.PUT_LINE(' BAO CAO TOAN HE THONG QUAN LY KHOA HOC');
    DBMS_OUTPUT.PUT_LINE('==========================================');
    DBMS_OUTPUT.PUT_LINE('Tong so mon hoc : ' || v_so_mon);
    DBMS_OUTPUT.PUT_LINE('Tong so lop hoc : ' || v_so_lop);
    DBMS_OUTPUT.PUT_LINE('Tong so sinh vien: ' || v_so_sv);
    DBMS_OUTPUT.PUT_LINE('Tong so giao vien: ' || v_so_gv);
    DBMS_OUTPUT.PUT_LINE(RPAD('-', 50, '-'));

    -- Phan 1: Thong ke giao vien
    DBMS_OUTPUT.PUT_LINE('THONG KE GIAO VIEN:');

    FOR rec IN (SELECT * FROM vw_instructor_workload) LOOP
        DBMS_OUTPUT.PUT_LINE(
            ' ' || RPAD(rec.ho_ten, 25)
            || ' | ' || LPAD(rec.so_lop, 2) || ' lop'
            || ' | ' || LPAD(rec.tong_sv, 3) || ' SV'
            || ' | DTB: ' || NVL(TO_CHAR(rec.diem_tb_chung), '--')
            || ' | ' || rec.muc_ban
        );
    END LOOP;

    DBMS_OUTPUT.PUT_LINE(RPAD('-', 50, '-'));

    -- Phan 2: Top 3 mon hoc
    DBMS_OUTPUT.PUT_LINE('TOP 3 MON HOC DUOC DANG KY NHIEU NHAT:');

    FOR rec IN (SELECT * FROM vw_top_courses WHERE hang <= 3) LOOP
        DBMS_OUTPUT.PUT_LINE(
            ' ' || rec.hang || '. '
            || RPAD(rec.description, 30)
            || ' - ' || rec.tong_dk || ' luot dang ky'
        );
    END LOOP;

    DBMS_OUTPUT.PUT_LINE('==========================================');
END print_system_report;
/

-- Chay bao cao:
SET SERVEROUTPUT ON SIZE 1000000;

BEGIN
    print_system_report;
END;
/