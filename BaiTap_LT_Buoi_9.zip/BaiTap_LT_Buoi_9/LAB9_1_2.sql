-- PHIEU BAI TAP 1 + PHIEU BAI TAP 2

-- XOA DOI TUONG CU

BEGIN EXECUTE IMMEDIATE 'DROP TABLE Hoadon CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE Hang CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE Nhatkybanhang CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP TABLE Mathang CASCADE CONSTRAINTS'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PACKAGE pkg_nkbh_state'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PROCEDURE sp_xoa_mathang'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP FUNCTION fn_tongtien_theo_tenhang'; EXCEPTION WHEN OTHERS THEN NULL; END;
/


-- PHIEU BAI TAP 1

-- 1a. TAO BANG
CREATE TABLE Hang(
    Mahang VARCHAR2(10) PRIMARY KEY,
    Tenhang VARCHAR2(100),
    Soluong NUMBER,
    Giaban NUMBER
);

CREATE TABLE Hoadon(
    Mahd NUMBER PRIMARY KEY,
    Mahang VARCHAR2(10),
    Soluongban NUMBER,
    Ngayban DATE,
    FOREIGN KEY (Mahang) REFERENCES Hang(Mahang)
);

-- Bài 1 – Trigger INSERT
CREATE OR REPLACE TRIGGER trg_hoadon_insert
BEFORE INSERT ON Hoadon
FOR EACH ROW
DECLARE
    v_soluong NUMBER;
BEGIN
    SELECT Soluong INTO v_soluong
    FROM Hang
    WHERE Mahang = :NEW.Mahang;

    IF :NEW.Soluongban > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20001,'Khong du ton kho');
    END IF;

    UPDATE Hang
    SET Soluong = Soluong - :NEW.Soluongban
    WHERE Mahang = :NEW.Mahang;

END;
/

-- Bài 2 – Trigger DELETE
CREATE OR REPLACE TRIGGER trg_hoadon_delete
AFTER DELETE ON Hoadon
FOR EACH ROW
BEGIN
    UPDATE Hang
    SET Soluong = Soluong + :OLD.Soluongban
    WHERE Mahang = :OLD.Mahang;
END;
/

-- Bài 3 – Trigger UPDATE
CREATE OR REPLACE TRIGGER trg_hoadon_update
BEFORE UPDATE ON Hoadon
FOR EACH ROW
BEGIN
    UPDATE Hang
    SET Soluong = Soluong - (:NEW.Soluongban - :OLD.Soluongban)
    WHERE Mahang = :NEW.Mahang;
END;
/

-- PHIEU BAI TAP 2

-- 2a. TAO BANG
CREATE TABLE Mathang(
    Mahang VARCHAR2(5) PRIMARY KEY,
    Tenhang VARCHAR2(50),
    Soluong NUMBER
);

CREATE TABLE Nhatkybanhang(
    Stt NUMBER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    Ngay DATE,
    Nguoimua VARCHAR2(50),
    Mahang VARCHAR2(5),
    Soluong NUMBER,
    Giaban NUMBER,
    FOREIGN KEY (Mahang) REFERENCES Mathang(Mahang)
);

-- 2b. DU LIEU MAU
INSERT INTO Mathang VALUES('1','Hang A',100);
INSERT INTO Mathang VALUES('2','Hang B',200);
INSERT INTO Mathang VALUES('3','Hang C',150);
COMMIT;

-- 2c. PACKAGE DEM DONG
CREATE OR REPLACE PACKAGE pkg_nkbh_state AS
    g_row_count NUMBER := 0;
END pkg_nkbh_state;
/

-- 2d. TRIGGER INSERT
CREATE OR REPLACE TRIGGER trg_nhatkybanhang_insert
BEFORE INSERT ON Nhatkybanhang
FOR EACH ROW
DECLARE
    v_soluong NUMBER;
BEGIN
    SELECT Soluong INTO v_soluong
    FROM Mathang
    WHERE Mahang = :NEW.Mahang;

    IF :NEW.Soluong > v_soluong THEN
        RAISE_APPLICATION_ERROR(-20011,'Vuot ton kho');
    END IF;

    UPDATE Mathang
    SET Soluong = Soluong - :NEW.Soluong
    WHERE Mahang = :NEW.Mahang;
END;
/

-- 2e. TRIGGER UPDATE
CREATE OR REPLACE TRIGGER trg_nkbh_update
FOR UPDATE ON Nhatkybanhang
COMPOUND TRIGGER

BEFORE STATEMENT IS
BEGIN
    pkg_nkbh_state.g_row_count := 0;
END BEFORE STATEMENT;

BEFORE EACH ROW IS
BEGIN
    pkg_nkbh_state.g_row_count := pkg_nkbh_state.g_row_count + 1;

    IF pkg_nkbh_state.g_row_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20021,'Chi duoc update 1 dong');
    END IF;
END BEFORE EACH ROW;

AFTER EACH ROW IS
BEGIN
    UPDATE Mathang
    SET Soluong = Soluong - (:NEW.Soluong - :OLD.Soluong)
    WHERE Mahang = :NEW.Mahang;
END AFTER EACH ROW;

END;
/

-- 2f. TRIGGER DELETE
CREATE OR REPLACE TRIGGER trg_nkbh_delete
FOR DELETE ON Nhatkybanhang
COMPOUND TRIGGER

BEFORE STATEMENT IS
BEGIN
    pkg_nkbh_state.g_row_count := 0;
END BEFORE STATEMENT;

BEFORE EACH ROW IS
BEGIN
    pkg_nkbh_state.g_row_count := pkg_nkbh_state.g_row_count + 1;

    IF pkg_nkbh_state.g_row_count > 1 THEN
        RAISE_APPLICATION_ERROR(-20031,'Chi duoc delete 1 dong');
    END IF;
END BEFORE EACH ROW;

AFTER EACH ROW IS
BEGIN
    UPDATE Mathang
    SET Soluong = Soluong + :OLD.Soluong
    WHERE Mahang = :OLD.Mahang;
END AFTER EACH ROW;

END;
/

-- 2g. PROCEDURE XOA MATHANG
CREATE OR REPLACE PROCEDURE sp_xoa_mathang(p_mahang VARCHAR2)
IS
    v_count NUMBER;
BEGIN

    SELECT COUNT(*) INTO v_count
    FROM Mathang
    WHERE Mahang = p_mahang;

    IF v_count = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Ma hang khong ton tai');
    ELSE
        DELETE FROM Nhatkybanhang WHERE Mahang = p_mahang;
        DELETE FROM Mathang WHERE Mahang = p_mahang;
        DBMS_OUTPUT.PUT_LINE('Da xoa');
    END IF;

END;
/

-- 2h. FUNCTION TONG TIEN
CREATE OR REPLACE FUNCTION fn_tongtien_theo_tenhang(p_tenhang VARCHAR2)
RETURN NUMBER
IS
    v_tong NUMBER;
BEGIN

    SELECT NVL(SUM(n.Soluong * n.Giaban),0)
    INTO v_tong
    FROM Nhatkybanhang n
    JOIN Mathang m ON n.Mahang = m.Mahang
    WHERE m.Tenhang = p_tenhang;

    RETURN v_tong;

END;
/

-- TEST

INSERT INTO Hoadon VALUES(1,'H01',10,SYSDATE);

INSERT INTO Nhatkybanhang(Ngay,Nguoimua,Mahang,Soluong,Giaban)
VALUES(SYSDATE,'A','1',10,50000);

UPDATE Nhatkybanhang
SET Soluong = 15
WHERE Stt = 1;

DELETE FROM Nhatkybanhang
WHERE Stt = 1;

SELECT fn_tongtien_theo_tenhang('Hang A') FROM dual;