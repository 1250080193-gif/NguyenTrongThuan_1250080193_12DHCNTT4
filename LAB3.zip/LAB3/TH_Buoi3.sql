SET SERVEROUTPUT ON;

DROP TABLE GRADE CASCADE CONSTRAINTS;
DROP TABLE ENROLLMENT CASCADE CONSTRAINTS;
DROP TABLE CLASS CASCADE CONSTRAINTS;
DROP TABLE STUDENT CASCADE CONSTRAINTS;
DROP TABLE INSTRUCTOR CASCADE CONSTRAINTS;
DROP TABLE COURSE CASCADE CONSTRAINTS;

-- COURSE
CREATE TABLE COURSE (
    CourseNo NUMBER(8,0) PRIMARY KEY,
    Description VARCHAR2(50),
    Cost NUMBER(9,2),
    Prerequisite NUMBER(8,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);

-- INSTRUCTOR
CREATE TABLE INSTRUCTOR (
    InstructorID NUMBER(8) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25),
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);

-- STUDENT
CREATE TABLE STUDENT (
    StudentID NUMBER(8,0) PRIMARY KEY,
    Salutation VARCHAR2(5),
    FirstName VARCHAR2(25),
    LastName VARCHAR2(25) NOT NULL,
    Address VARCHAR2(50),
    Phone VARCHAR2(15),
    Employer VARCHAR2(50),
    RegistrationDate DATE NOT NULL,
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL
);

-- CLASS
CREATE TABLE CLASS (
    ClassID NUMBER(8,0) PRIMARY KEY,
    CourseNo NUMBER(8,0) NOT NULL,
    ClassNo NUMBER(3) NOT NULL,
    StartDateTime DATE,
    Location VARCHAR2(50),
    InstructorID NUMBER(8,0) NOT NULL,
    Capacity NUMBER(3,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,

    CONSTRAINT FK_CLASS_COURSE FOREIGN KEY (CourseNo) REFERENCES COURSE(CourseNo),
    CONSTRAINT FK_CLASS_INSTRUCTOR FOREIGN KEY (InstructorID) REFERENCES INSTRUCTOR(InstructorID)
);

-- ENROLLMENT
CREATE TABLE ENROLLMENT (
    StudentID NUMBER(8,0),
    ClassID NUMBER(8,0),
    EnrollDate DATE NOT NULL,
    FinalGrade NUMBER(3,0),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,

    CONSTRAINT PK_ENROLLMENT PRIMARY KEY (StudentID, ClassID),
    CONSTRAINT FK_ENR_STUDENT FOREIGN KEY (StudentID) REFERENCES STUDENT(StudentID),
    CONSTRAINT FK_ENR_CLASS FOREIGN KEY (ClassID) REFERENCES CLASS(ClassID)
);

--GRADE
CREATE TABLE GRADE (
    StudentID NUMBER(8),
    ClassID NUMBER(8),
    Grade NUMBER(3),
    Comments VARCHAR2(2000),
    CreatedBy VARCHAR2(30) NOT NULL,
    CreatedDate DATE NOT NULL,
    ModifiedBy VARCHAR2(30) NOT NULL,
    ModifiedDate DATE NOT NULL,

    CONSTRAINT PK_GRADE PRIMARY KEY (StudentID, ClassID),
    CONSTRAINT FK_GRADE_STUDENT FOREIGN KEY (StudentID) REFERENCES STUDENT(StudentID),
    CONSTRAINT FK_GRADE_CLASS FOREIGN KEY (ClassID) REFERENCES CLASS(ClassID)
);

-- COURSE
INSERT INTO COURSE VALUES (10, 'Database', 1000, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (20, 'Programming', 1200, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (30, 'AI', 1500, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (40, 'Web', 1300, NULL, USER, SYSDATE, USER, SYSDATE);
INSERT INTO COURSE VALUES (50, 'Data Mining', 1400, NULL, USER, SYSDATE, USER, SYSDATE);

-- INSTRUCTOR
INSERT INTO INSTRUCTOR VALUES (1,'Mr','Nguyen','A','HCM','0123',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (2,'Mr','Tran','B','HCM','0456',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (3,'Mr','Le','C','HCM','0777',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (4,'Ms','Vo','D','HCM','0888',USER,SYSDATE,USER,SYSDATE);
INSERT INTO INSTRUCTOR VALUES (5,'Mr','Pham','E','HCM','0999',USER,SYSDATE,USER,SYSDATE);

-- STUDENT 
INSERT INTO STUDENT VALUES (101,'Mr','Le','An','HCM','111',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (102,'Mr','Pham','Binh','HCM','222',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (103,'Mr','Nguyen','Cuong','HCM','333',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (104,'Ms','Tran','Dung','HCM','444',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (105,'Mr','Le','Huy','HCM','555',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (106,'Ms','Pham','Lan','HCM','666',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (107,'Mr','Hoang','Minh','HCM','777',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (108,'Ms','Do','Nga','HCM','888',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (109,'Mr','Nguyen','Tuan','HCM','999',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (110,'Ms','Tran','Hoa','HCM','100',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (111,'Mr','Le','Khanh','HCM','101',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (112,'Ms','Pham','Yen','HCM','102',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (113,'Mr','Vo','Nam','HCM','103',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (114,'Ms','Ho','Anh','HCM','104',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (115,'Mr','Do','Long','HCM','105',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (116,'Ms','Nguyen','Trang','HCM','106',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (117,'Mr','Tran','Kiet','HCM','107',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);
INSERT INTO STUDENT VALUES (118,'Ms','Le','Nhi','HCM','108',NULL,SYSDATE,USER,SYSDATE,USER,SYSDATE);

-- CLASS
INSERT INTO CLASS VALUES (1,10,1,SYSDATE,'A1',1,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (2,10,2,SYSDATE,'A2',1,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (3,20,1,SYSDATE,'B1',2,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (4,20,2,SYSDATE,'B2',2,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (5,10,3,SYSDATE,'A3',1,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (6,30,1,SYSDATE,'C1',3,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (7,30,2,SYSDATE,'C2',3,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (8,40,1,SYSDATE,'D1',4,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (9,50,1,SYSDATE,'E1',5,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (10,10,4,SYSDATE,'A4',1,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (11,10,5,SYSDATE,'A5',1,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (12,20,3,SYSDATE,'B3',2,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (13,20,4,SYSDATE,'B4',2,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (14,30,3,SYSDATE,'C3',3,30,USER,SYSDATE,USER,SYSDATE);
INSERT INTO CLASS VALUES (15,40,2,SYSDATE,'D2',4,30,USER,SYSDATE,USER,SYSDATE);

-- ENROLLMENT
INSERT INTO ENROLLMENT VALUES (101,1,SYSDATE,85,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (101,2,SYSDATE,90,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (101,3,SYSDATE,88,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (101,4,SYSDATE,92,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (101,5,SYSDATE,91,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (102,1,SYSDATE,70,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (102,2,SYSDATE,75,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (103,3,SYSDATE,60,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (104,6,SYSDATE,95,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (105,7,SYSDATE,80,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (106,8,SYSDATE,50,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (107,9,SYSDATE,40,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (108,10,SYSDATE,65,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (109,11,SYSDATE,70,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (110,12,SYSDATE,85,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (111,13,SYSDATE,90,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (112,14,SYSDATE,55,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (113,15,SYSDATE,60,USER,SYSDATE,USER,SYSDATE);

INSERT INTO ENROLLMENT VALUES (114,1,SYSDATE,75,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (115,2,SYSDATE,88,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (116,3,SYSDATE,92,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (117,4,SYSDATE,67,USER,SYSDATE,USER,SYSDATE);
INSERT INTO ENROLLMENT VALUES (118,5,SYSDATE,73,USER,SYSDATE,USER,SYSDATE);

-- GRADE
INSERT INTO GRADE VALUES (101,1,85,'Tot',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (102,2,70,'On dinh',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (103,3,60,'Can co gang',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (104,6,95,'Excellent',USER,SYSDATE,USER,SYSDATE);
INSERT INTO GRADE VALUES (105,7,80,'Good',USER,SYSDATE,USER,SYSDATE);

COMMIT;

--a + b: Tạo bảng + sequence
CREATE TABLE Cau1 (
ID NUMBER,
NAME VARCHAR2(20)
);

CREATE SEQUENCE Cau1Seq 
    START WITH 5 
    INCREMENT BY 5; 
    
SET SERVEROUTPUT ON;

DECLARE 
    v_name  VARCHAR2(50); 
    v_id    NUMBER; 
BEGIN 
    -- [d] Sinh vien dang ki nhieu mon nhat 
    SELECT firstname || ' ' || lastname 
    INTO v_name 
    FROM student 
    WHERE studentid = (
        SELECT studentid FROM (
            SELECT studentid
            FROM enrollment
            GROUP BY studentid
            ORDER BY COUNT(*) DESC
        ) WHERE ROWNUM = 1
    );

    INSERT INTO Cau1 (ID, NAME) 
    VALUES (Cau1Seq.NEXTVAL, v_name); 
    SAVEPOINT sp_a;    

    -- [e] Sinh vien dang ki it mon nhat 
    SELECT firstname || ' ' || lastname 
    INTO v_name 
    FROM student 
    WHERE studentid = (
        SELECT studentid FROM (
            SELECT studentid
            FROM enrollment
            GROUP BY studentid
            ORDER BY COUNT(*) ASC
        ) WHERE ROWNUM = 1
    );

    INSERT INTO Cau1 (ID, NAME) 
    VALUES (Cau1Seq.NEXTVAL, v_name); 
    SAVEPOINT sp_b;    

    -- [f] Giao vien day nhieu lop nhat 
    SELECT i.firstname || ' ' || i.lastname 
    INTO v_name 
    FROM instructor i 
    WHERE i.instructorid = (
        SELECT instructorid FROM (
            SELECT instructorid
            FROM class
            GROUP BY instructorid
            ORDER BY COUNT(*) DESC
        ) WHERE ROWNUM = 1
    );

    INSERT INTO Cau1 (ID, NAME) 
    VALUES (Cau1Seq.NEXTVAL, v_name); 
    SAVEPOINT sp_c;    

    -- [g] Lay ID vua them
    SELECT ID INTO v_id 
    FROM Cau1 
    WHERE NAME = v_name 
    AND ROWNUM = 1;

    DBMS_OUTPUT.PUT_LINE('ID giao vien nhieu lop: ' || v_id); 

    -- [h] Rollback ve sp_b
    ROLLBACK TO sp_b; 

    -- [i] Giao vien it lop nhat
    SELECT i.firstname || ' ' || i.lastname 
    INTO v_name 
    FROM instructor i 
    WHERE i.instructorid = (
        SELECT instructorid FROM (
            SELECT instructorid
            FROM class
            GROUP BY instructorid
            ORDER BY COUNT(*) ASC
        ) WHERE ROWNUM = 1
    );

    INSERT INTO Cau1 (ID, NAME) 
    VALUES (v_id, v_name);    

    -- [j] Them lai giao vien nhieu lop
    SELECT i.firstname || ' ' || i.lastname 
    INTO v_name 
    FROM instructor i 
    WHERE i.instructorid = (
        SELECT instructorid FROM (
            SELECT instructorid
            FROM class
            GROUP BY instructorid
            ORDER BY COUNT(*) DESC
        ) WHERE ROWNUM = 1
    );

    INSERT INTO Cau1 (ID, NAME) 
    VALUES (Cau1Seq.NEXTVAL, v_name);    

    COMMIT; 
    DBMS_OUTPUT.PUT_LINE('Hoan tat! Kiem tra: SELECT * FROM Cau1;'); 

EXCEPTION 
    WHEN NO_DATA_FOUND THEN 
        DBMS_OUTPUT.PUT_LINE('Loi: Khong tim thay du lieu!');
        ROLLBACK; 

    WHEN OTHERS THEN 
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM); 
        ROLLBACK; 
END; 
/


--Cau 2

SET SERVEROUTPUT ON;

DECLARE 
    v_sid     NUMBER        := &ma_sinh_vien; 
    v_fname   VARCHAR2(25)  := '&ho_sinh_vien'; 
    v_lname   VARCHAR2(25)  := '&ten_sinh_vien'; 
    v_addr    VARCHAR2(50)  := '&dia_chi'; 
    v_found   VARCHAR2(50); 
    v_classes NUMBER; 
BEGIN 
    -- Tim sinh vien theo ma vua nhap 
    SELECT firstname || ' ' || lastname 
    INTO   v_found 
    FROM   student 
    WHERE  studentid = v_sid; 

    -- Dem so lop dang hoc 
    SELECT COUNT(*) 
    INTO   v_classes 
    FROM   enrollment 
    WHERE  studentid = v_sid; 

    DBMS_OUTPUT.PUT_LINE('Ho ten: ' || v_found); 
    DBMS_OUTPUT.PUT_LINE('So lop dang hoc: ' || v_classes);

EXCEPTION 
    WHEN NO_DATA_FOUND THEN 
        -- Neu khong ton tai -> them moi 
        DBMS_OUTPUT.PUT_LINE('Sinh vien chua ton tai. Dang them moi...'); 

        INSERT INTO student (studentid, firstname, lastname) 
        VALUES (v_sid, v_fname, v_lname); 

        COMMIT; 

        DBMS_OUTPUT.PUT_LINE('Da them sinh vien moi: ' || v_fname || ' ' || v_lname); 
END; 
/


--BÀI 2: Các Cấu Trúc Điều Khiển - IF và CASE 
--Cau1

SET SERVEROUTPUT ON;

DECLARE 
    v_instructor_id  NUMBER := &ma_giao_vien; 
    v_so_lop         NUMBER; 
    v_check          NUMBER;
BEGIN 
    -- Kiem tra giao vien ton tai
    SELECT COUNT(*) 
    INTO v_check 
    FROM instructor 
    WHERE instructorid = v_instructor_id;

    IF v_check = 0 THEN
        DBMS_OUTPUT.PUT_LINE('Khong tim thay giao vien co ma: ' || v_instructor_id);
        RETURN;
    END IF;

    -- Dem so lop giao vien dang day 
    SELECT COUNT(*) 
    INTO v_so_lop 
    FROM class 
    WHERE instructorid = v_instructor_id; 

    -- Phan nhanh theo ket qua 
    IF v_so_lop >= 5 THEN 
        DBMS_OUTPUT.PUT_LINE('Giao vien nay nen nghi ngoi!'); 
    ELSE 
        DBMS_OUTPUT.PUT_LINE('So lop giao vien dang day: ' || v_so_lop); 
    END IF; 

END; 
/

--Cau2

SET SERVEROUTPUT ON;

DECLARE 
    v_sid    NUMBER := &ma_sinh_vien; 
    v_cid    NUMBER := &ma_lop; 
    v_score  NUMBER; 
    v_grade  VARCHAR2(2); 
    v_check  NUMBER; 
BEGIN 
    -- Kiem tra sinh vien ton tai 
    SELECT COUNT(*) INTO v_check 
    FROM student 
    WHERE studentid = v_sid; 

    IF v_check = 0 THEN 
        DBMS_OUTPUT.PUT_LINE('Loi: Ma sinh vien ' || v_sid || ' khong ton tai!'); 
        RETURN; 
    END IF; 

    -- Kiem tra lop ton tai 
    SELECT COUNT(*) INTO v_check 
    FROM class 
    WHERE classid = v_cid; 

    IF v_check = 0 THEN 
        DBMS_OUTPUT.PUT_LINE('Loi: Ma lop ' || v_cid || ' khong ton tai!'); 
        RETURN; 
    END IF; 

    -- Lay diem cua sinh vien trong lop 
    SELECT finalgrade 
    INTO v_score 
    FROM enrollment 
    WHERE studentid = v_sid AND classid = v_cid; 

    -- Quy doi diem so sang diem chu 
    CASE 
        WHEN v_score >= 90 THEN v_grade := 'A'; 
        WHEN v_score >= 80 THEN v_grade := 'B'; 
        WHEN v_score >= 70 THEN v_grade := 'C'; 
        WHEN v_score >= 50 THEN v_grade := 'D'; 
        ELSE v_grade := 'F'; 
    END CASE; 

    DBMS_OUTPUT.PUT_LINE('Diem so: ' || v_score || ' -> Diem chu: ' || v_grade); 

EXCEPTION 
    WHEN NO_DATA_FOUND THEN 
        DBMS_OUTPUT.PUT_LINE('Sinh vien chua dang ky lop nay hoac chua co diem!'); 
END; 
/

--BÀI 3: Cursor - Duyệt Tập Kết Quả

SET SERVEROUTPUT ON;

DECLARE
    -- Cursor 1: môn học
    CURSOR c_course IS
        SELECT courseno, description FROM course;

    -- Cursor 2: lớp theo môn
    CURSOR c_class(p_courseno NUMBER) IS
        SELECT classid FROM class WHERE courseno = p_courseno;

    v_count NUMBER;
BEGIN
    FOR c IN c_course LOOP
        DBMS_OUTPUT.PUT_LINE(c.courseno || ' ' || c.description);

        FOR cl IN c_class(c.courseno) LOOP
            SELECT COUNT(*) INTO v_count
            FROM enrollment
            WHERE classid = cl.classid;

            DBMS_OUTPUT.PUT_LINE('   Lop: ' || cl.classid || 
                                 ' co so luong SV: ' || v_count);
        END LOOP;
    END LOOP;
END;
/



--BÀI 4: Thủ Tục (Procedure) Và Hàm (Function)
--Câu 4.1a: Thủ tục find_sname - nhận mã SV, trả về FirstName và LastName
CREATE OR REPLACE PROCEDURE find_sname 
    (i_student_id  IN   student.studentid%TYPE, 
     o_first_name  OUT  student.firstname%TYPE, 
     o_last_name   OUT  student.lastname%TYPE) 
IS 
BEGIN 
    SELECT firstname, lastname 
    INTO   o_first_name, o_last_name 
    FROM   student 
    WHERE  studentid = i_student_id; 
 
EXCEPTION 
    WHEN NO_DATA_FOUND THEN 
        o_first_name := NULL; 
        o_last_name  := NULL; 
        DBMS_OUTPUT.PUT_LINE('Khong tim thay sinh vien ID: ' || 
i_student_id); 
END find_sname; 
/ 

--Câu 4.1b: Thủ tục print_student_name  nhận mã SV, gọi find_sname và in tên ra màn hình 
CREATE OR REPLACE PROCEDURE print_student_name 
    (i_student_id  IN  student.studentid%TYPE) 
IS 
    v_first  student.firstname%TYPE; 
    v_last   student.lastname%TYPE; 
BEGIN 
    -- Goi thu tuc find_sname da co san 
    find_sname(i_student_id, v_first, v_last); 
 
    IF v_first IS NOT NULL OR v_last IS NOT NULL THEN 
        DBMS_OUTPUT.PUT_LINE('Ho ten sinh vien: ' || v_first || ' ' || 
v_last); 
    END IF; 
END print_student_name; 
/ 
 -- Goi thu tuc de kiem tra: 
BEGIN 
    print_student_name(101); 
END; 
/

--Câu 4.2: Thủ tục Discount - giảm 5% cho môn học có hơn 15 sinh viên đăng ký
CREATE OR REPLACE PROCEDURE Discount 
IS 
BEGIN 
    FOR rec IN ( 
        SELECT c.courseno, c.description, c.cost 
        FROM   course c
         WHERE  (SELECT COUNT(*) FROM enrollment e 
                JOIN class cl ON e.classid = cl.classid 
                WHERE cl.courseno = c.courseno) > 15 
    ) LOOP 
        -- Giam gia 5% 
        UPDATE course 
        SET    cost = cost * 0.95 
        WHERE  courseno = rec.courseno; 
 
        DBMS_OUTPUT.PUT_LINE('Da giam gia mon hoc: ' || rec.description 
                             || ' | Gia cu: ' || rec.cost 
                             || ' | Gia moi: ' || ROUND(rec.cost * 0.95, 2)); 
    END LOOP; 
 
    COMMIT; 
    DBMS_OUTPUT.PUT_LINE('Hoan tat giam gia.'); 
EXCEPTION 
    WHEN OTHERS THEN 
        ROLLBACK; 
        DBMS_OUTPUT.PUT_LINE('Loi: ' || SQLERRM); 
END Discount; 
/ 
 -- Goi thu tuc: 
BEGIN Discount; END; 
/


--Câu 4.3: Hàm Total_cost_for_student - trả về tổng chi phí một sinh viên phải trả; NULL nếu không tồn tại
CREATE OR REPLACE FUNCTION Total_cost_for_student 
    (p_student_id  IN  student.studentid%TYPE) 
RETURN NUMBER 
IS 
    v_total   NUMBER; 
    v_check   NUMBER; 
BEGIN 
    -- Kiem tra sinh vien co ton tai khong 
    SELECT COUNT(*) INTO v_check 
    FROM   student WHERE studentid = p_student_id; 
 
    IF v_check = 0 THEN 
        RETURN NULL;    -- Sinh vien khong ton tai 
    END IF; 
 
    -- Tinh tong chi phi: sum(cost cua tung mon da dang ky) 
    SELECT NVL(SUM(co.cost), 0) 
    INTO   v_total 
    FROM   enrollment e 
    JOIN   class      cl ON e.classid = cl.classid 
    JOIN   course     co ON cl.courseno = co.courseno 
    WHERE  e.studentid = p_student_id; 
 
    RETURN v_total; 
 
EXCEPTION 
    WHEN OTHERS THEN 
        RETURN NULL; 
END Total_cost_for_student; 
/ 
 -- Goi ham de kiem tra: 
SELECT Total_cost_for_student(101) AS "Tong chi phi" FROM DUAL; 
 -- Hoac trong PL/SQL: 
BEGIN 
    DBMS_OUTPUT.PUT_LINE('Tong chi phi: ' || Total_cost_for_student(101)); 
END; 
/ 


--BÀI 5: Trigger
--Câu 5.1: Trigger tự động điền created_by, created_date, modified_by, modified_date cho tất cả các bảng 
-- COURSE
CREATE OR REPLACE TRIGGER trg_course_audit 
BEFORE INSERT OR UPDATE ON course 
FOR EACH ROW 
BEGIN 
    IF INSERTING THEN 
        :NEW.CreatedBy   := USER; 
        :NEW.CreatedDate := SYSDATE; 
    END IF; 
    :NEW.ModifiedBy   := USER; 
    :NEW.ModifiedDate := SYSDATE; 
END;
/

-- CLASS
CREATE OR REPLACE TRIGGER trg_class_audit 
BEFORE INSERT OR UPDATE ON class 
FOR EACH ROW 
BEGIN 
    IF INSERTING THEN 
        :NEW.CreatedBy   := USER; 
        :NEW.CreatedDate := SYSDATE; 
    END IF; 
    :NEW.ModifiedBy   := USER; 
    :NEW.ModifiedDate := SYSDATE; 
END;
/

-- STUDENT
CREATE OR REPLACE TRIGGER trg_student_audit 
BEFORE INSERT OR UPDATE ON student 
FOR EACH ROW 
BEGIN 
    IF INSERTING THEN 
        :NEW.CreatedBy   := USER; 
        :NEW.CreatedDate := SYSDATE; 
    END IF; 
    :NEW.ModifiedBy   := USER; 
    :NEW.ModifiedDate := SYSDATE; 
END;
/

-- ENROLLMENT
CREATE OR REPLACE TRIGGER trg_enrollment_audit 
BEFORE INSERT OR UPDATE ON enrollment 
FOR EACH ROW 
BEGIN 
    IF INSERTING THEN 
        :NEW.CreatedBy   := USER; 
        :NEW.CreatedDate := SYSDATE; 
    END IF; 
    :NEW.ModifiedBy   := USER; 
    :NEW.ModifiedDate := SYSDATE; 
END;
/

-- INSTRUCTOR
CREATE OR REPLACE TRIGGER trg_instructor_audit 
BEFORE INSERT OR UPDATE ON instructor 
FOR EACH ROW 
BEGIN 
    IF INSERTING THEN 
        :NEW.CreatedBy   := USER; 
        :NEW.CreatedDate := SYSDATE; 
    END IF; 
    :NEW.ModifiedBy   := USER; 
    :NEW.ModifiedDate := SYSDATE; 
END;
/

-- GRADE
CREATE OR REPLACE TRIGGER trg_grade_audit 
BEFORE INSERT OR UPDATE ON grade 
FOR EACH ROW 
BEGIN 
    IF INSERTING THEN 
        :NEW.CreatedBy   := USER; 
        :NEW.CreatedDate := SYSDATE; 
    END IF; 
    :NEW.ModifiedBy   := USER; 
    :NEW.ModifiedDate := SYSDATE; 
END;
/

--Câu 5.2: Trigger kiểm tra: mỗi sinh viên không được đăng ký quá 3 lớp học 
CREATE OR REPLACE TRIGGER trg_max_enrollment 
BEFORE INSERT ON enrollment 
FOR EACH ROW 
DECLARE 
    v_so_lop NUMBER; 
BEGIN 
    -- Dem so lop hien tai (da dang ky)
    SELECT COUNT(*) 
    INTO v_so_lop 
    FROM enrollment 
    WHERE studentid = :NEW.studentid; 

    -- Gioi han toi da 3 lop
    IF v_so_lop >= 3 THEN 
        RAISE_APPLICATION_ERROR( 
            -20001, 
            'Sinh vien ' || :NEW.studentid || 
            ' da dang ky du 3 lop! Khong the dang ky them.' 
        ); 
    END IF; 
END;
/